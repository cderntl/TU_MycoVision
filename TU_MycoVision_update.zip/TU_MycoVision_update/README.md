# TU_MyCo-Vision: A Deep Learning Tool for Detection of Cell Morphologies in Fungal Microscopic Images

- TU_MyCo-Vision is an Ultralytics YOLOv11m-powered fungal cell detection and analysis tool.
- Designed to detect 13 different fungal cell morphologies in bright-field microscopic images.
- The tool is an end-to-end solution that integrates: Detection - Data Analysis - Visualization.

## Key Features
- Training & Validation dataset of 1504 images, comprising *Aureobasidium pullulans*, *A. melanogenum*, and *Trichoderma reesei*.
- Cross-species compatibility (Tested on images of *Komagataella phaffii* strains, *Candida albicans*, and *Aspergillus niger* spores).
- Class definitions untied from species-specific or cultivation condition-specific phenotypes, enabling wider compatibility with different research questions.
- Graphical User Interface for non-programmers, which combines:
  - Image detection.
  - New "Custom class names" feature to change default class labels to any desired label.
  - Quantitative data analysis that supports:
    - Analysis of all images within a single sample group (Single-Group Analysis).
    - Analysis across multiple sample groups (Multi-Group Analysis).
    - Analysis with groups defined by custom text strings, with a preview and approval step.
    - Multiple input folders and recursive search for images and results.
    - Live output log and automatic export of named plots.
    - Interactive plots generated using Plotly (v6.1.2).
  - Result Preview:
    - Paired preview of original and annotated images for qualitative analysis.
## Performance
(Validated on global_test_dataset)
| Class | Precision | Recall | mAP@50 | mAP@50-95 |
| :-- | :-- | :-- | :-- | :-- |
| all | 0.734 | 0.665 | 0.735 | 0.545 |
| C2 | 0.839 | 0.851 | 0.912 | 0.730 |
| C5 | 0.709 | 0.789 | 0.792 | 0.587 |
| C1 | 0.762 | 0.731 | 0.844 | 0.677 |
| C4 | 0.811 | 0.475 | 0.622 | 0.327 |
| C6 | 0.639 | 0.600 | 0.699 | 0.560 |
| C11 | 0.613 | 0.583 | 0.612 | 0.480 |
| C9 | 0.557 | 0.579 | 0.583 | 0.459 |
| C2-B | 0.865 | 0.739 | 0.887 | 0.729 |
| C3-B | 0.778 | 0.949 | 0.900 | 0.730 |
| C8 | 0.900 | 0.846 | 0.897 | 0.790 |
| C7-E | 0.664 | 0.446 | 0.577 | 0.338 |
| C7-F | 0.720 | 0.571 | 0.712 | 0.391 |
| C7-G | 0.680 | 0.479 | 0.517 | 0.291 |

## Scripts
1. `cropper.py`  
   Used for generating 640 × 640 crops from 1920 × 1080 images while implementing a dataset expansion strategy.
2. `annotation_handler.py`  
   Counts the number of objects belonging to each label in a dataset with annotations in JSON format.
3. `kfold_splitter.py`  
   Used to split each dataset family into 5 train and validation splits. Base code adapted from Ultralytics (https://docs.ultralytics.com/guides/kfold-cross-validation/).
4. `hyperparameter_tuning.py`  
   Script used to perform hyperparameter search using the `model.tune()` method in Ultralytics. Base code adapted from Ultralytics (https://docs.ultralytics.com/guides/hyperparameter-tuning/).
5. `cross_validation_training.py`
   Script used to perfom the training with cross-validation on all 5 dataset splits.
7. `datafeed_prediction.py`  
   Script used for running the prediction function in the Ultralytics YOLO framework for auto-labelling operations.
8. `all_validator.py`  
   Script used for validating all MyCo-Vision model families on the global test dataset.

## Installation (Windows, macOS, Linux)

The installers need only an internet connection and about 6 GB of free disk space. They need no admin rights.
They set up a private conda environment, download the model and images from the [v1.0.0 release](https://github.com/cderntl/TU_MycoVision/releases/tag/v1.0.0), and add a shortcut.
If conda is missing, they install Miniforge (a small, free conda) inside the install folder.

**Windows 10/11**
1. Download `installers/install_windows.bat`.
2. Double-click it and wait. The first run takes 10 to 20 minutes.
3. Start **TU_MyCo-Vision** from the Desktop or Start menu.

**macOS and Linux**
```bash
curl -fsSL https://raw.githubusercontent.com/cderntl/TU_MycoVision/main/installers/install_linux_macos.sh | bash
```
Or download `installers/install_linux_macos.sh` and run `bash install_linux_macos.sh`.
- macOS: open `TU_MyCo-Vision` in `~/Applications`.
- Linux: use the application menu entry, or run `tu-myco-vision`.

Details:
- Default install folder: `~/TU_MyCo-Vision` (Windows: `%USERPROFILE%\TU_MyCo-Vision`). Change it with `--dir PATH` (Windows: `-Dir PATH`).
- To see the steps without changing anything, add `--dry-run` (Windows: `-DryRun`).
- To update, run the installer again.
- To uninstall, delete the install folder and the shortcut.
- If the program does not start on Windows, run `TU_MyCo-Vision_with_console.bat` in the install folder to see the error.
- Manual setup from a clone: `conda env create -f environment.yml`, put `TU_MyCo-Vision.pt`, `aureo1.png` and `reference.png` from the release next to `TU_MyCo-Vision_v1_source_code.py`, then run `python TU_MyCo-Vision_v1_source_code.py`.

## Using the program

**Detection**
- Add one or more image folders (buttons, or drag and drop). Tick *Include subfolders* to find images recursively.
- Each image folder is processed on its own. Results go to `<output>/<analysis name>/<picked folder>/<subfolder>/`, so images with the same file name in different folders never overwrite each other.
  With a single flat folder the results go straight into `<output>/<analysis name>/`, as in version 1.
- The **Output log** at the bottom shows what the model prints. The progress bar moves after every image. **Stop** ends the run after the current image.
- Dialogs open in the folder you used last time. Image and output folders are remembered between sessions.

**Analysis** (three ways to define groups)
- *Single Group*: all label files below one results folder.
- *Multi Group*: every folder you add is one group.
- *Custom Groups (by text)*: you type the strings that identify each group.
  - Matching is case-insensitive and checks the folder path and the file name together.
  - `ctrl` matches any path containing "ctrl". A string that matches two folders puts both folders in one group. A string that is part of file names groups those images.
  - Use `*` and `?` as wildcards (`WT*_day1`). Start with `re:` for a regular expression. Separate several strings with commas.
  - Press *Preview Groups*. A window shows which file goes to which group, plus files that match nothing or several groups. **Nothing is analysed until you press "Approve and run analysis".**
- Every analysis saves its CSV files and **exports all plots automatically** to `<output>/<analysis name>_plots/`. File names start with the analysis name, for example `Run1_relative_abundance.html`.

**Results Dashboard**
- *Click to View Plots* opens all plots in the browser. The page has a **Download all plots** button that saves every plot as PNG, SVG, JPEG or WebP.
- *Download all plots* in the program saves every plot as an HTML file named after the analysis.

## For developers
```bash
conda env create -f environment.yml && conda activate <env>
pip install pytest && pytest tests          # QT_QPA_PLATFORM=offscreen is set by the tests
```
- `myco_core.py`: image and label discovery, label parsing, group matching (no GUI).
- `myco_plots.py`: plot building and export.
- `myco_qtutils.py`: GUI helpers (folder list, log panel, group table and approval window).

## Credits and Attributions

See the credits.md for list of all third-party packages and cited libraries used in this project.

## Acknowledgements
Developed as a part of study on polymorphism in *Aureobasidium pullulans*. Special thanks to all the contributors. This research was funded in whole or in part by the Austrian Science Fund (FWF) [10.55776/P 35642]. For open access purposes, the author has applied a CC BY public copyright license.

## AI Usage Declaration

Parts of the codes in this repository was written with the help of generative AI tools ("vibe coding"). All AI-generated code was manually reviewed and tested by the contributors to ensure the intended functionality to the best of their abilities. 
