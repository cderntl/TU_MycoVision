"""TU_MyCo-Vision plots: build, name and export the Plotly figures (no Qt)."""

from __future__ import annotations

import html as _html
import json
import re
from pathlib import Path
from typing import List, Tuple

# (file-name part, human title, figure)
NamedFigure = Tuple[str, str, object]


def safe_name(text: str, default: str = "analysis") -> str:
    """Make text safe for file names on Windows, macOS and Linux."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", (text or "").strip()).strip("._")
    return cleaned or default


def analysis_name_from_csv(csv_path) -> str:
    """'MyRun_rawdata.csv' -> 'MyRun'; 'MyRun_excluded.csv' -> 'MyRun_excluded'."""
    stem = Path(csv_path).stem
    return stem[:-len("_rawdata")] if stem.endswith("_rawdata") else stem


def build_figures(df) -> List[NamedFigure]:
    """Build all figures for a count table (single-group or multi-group)."""
    import numpy as np  # noqa: F401  (kept for parity with older versions)
    import plotly.express as px
    import plotly.graph_objs as go
    from scipy.cluster.hierarchy import leaves_list, linkage

    has_group = "Group" in df.columns
    classes = [c for c in df.columns if c not in ("Image", "Group")]
    palette = px.colors.qualitative.Plotly + px.colors.qualitative.Vivid
    figs: List[NamedFigure] = []

    # 1. Absolute cell counts
    if has_group:
        group_abs = df.groupby("Group")[classes].sum()
        fig = go.Figure()
        for i, group in enumerate(group_abs.index):
            fig.add_trace(go.Bar(
                x=classes, y=group_abs.loc[group].values, name=str(group),
                marker_color=palette[i % len(palette)],
                text=[str(int(v)) for v in group_abs.loc[group].values],
                textposition="outside",
                hovertemplate=f"Group: {group}<br>Class: %{{x}}<br>Count: %{{y}}<extra></extra>"))
        fig.update_layout(barmode="group",
                          title="Absolute Cell Counts by Class per Group",
                          xaxis_title="Class", yaxis_title="Total Count",
                          template="plotly_white")
    else:
        abs_sum = df[classes].sum()
        fig = go.Figure()
        fig.add_trace(go.Bar(x=classes, y=abs_sum,
                             marker_color=palette[:len(classes)],
                             text=[str(int(v)) for v in abs_sum],
                             textposition="outside"))
        fig.update_layout(title="Absolute Cell Counts by Class",
                          xaxis_title="Class", yaxis_title="Total Count",
                          template="plotly_white")
    figs.append(("absolute_counts", "Absolute cell counts", fig))

    # 2. Relative abundance
    if has_group:
        group_totals = df.groupby("Group")[classes].sum()
        group_total_counts = group_totals.sum(axis=1)
        fig = go.Figure()
        for i, group in enumerate(group_totals.index):
            rel_pct = (group_totals.loc[group] / group_total_counts[group] * 100).round(2)
            fig.add_trace(go.Bar(
                x=classes, y=rel_pct, name=str(group),
                marker_color=palette[i % len(palette)],
                text=[f"{v:.1f}%" for v in rel_pct], textposition="outside",
                hovertemplate=f"Group: {group}<br>Class: %{{x}}<br>Rel %: %{{y:.2f}}%<extra></extra>"))
        fig.update_layout(barmode="group",
                          title="Relative Abundance (%) by Class per Group",
                          xaxis_title="Class", yaxis_title="(%) Abundance",
                          template="plotly_white")
    else:
        total = df[classes].sum()
        rel_pct = (total / total.sum() * 100).round(2)
        fig = go.Figure(data=[go.Bar(
            x=classes, y=rel_pct, text=[f"{v:.1f}%" for v in rel_pct],
            textposition="outside", marker_color=palette[:len(classes)])])
        fig.update_layout(title="Relative Abundance (%) of Morphotypes",
                          xaxis_title="Class", yaxis_title="(%) Abundance",
                          template="plotly_white")
    figs.append(("relative_abundance", "Relative abundance", fig))

    # 3. Mean relative abundance (per image, then averaged)
    rel_df = df[classes].div(df[classes].sum(axis=1).replace(0, 1), axis=0)
    if has_group:
        rel_mean = rel_df.copy()
        rel_mean["Group"] = df["Group"]
        rel_grp = rel_mean.groupby("Group").mean() * 100
        fig = go.Figure()
        for i, group in enumerate(rel_grp.index):
            fig.add_trace(go.Bar(
                x=classes, y=rel_grp.loc[group].values, name=str(group),
                marker_color=palette[i % len(palette)],
                text=[f"{v:.1f}%" for v in rel_grp.loc[group].values],
                textposition="outside",
                hovertemplate=f"Group: {group}<br>Class: %{{x}}<br>Mean %: %{{y:.2f}}%<extra></extra>"))
        fig.update_layout(barmode="group",
                          title="Mean Relative Abundance (%) by Class per Group",
                          xaxis_title="Class",
                          yaxis_title="Mean Relative Abundance (%)",
                          template="plotly_white")
    else:
        rel_mean_vals = rel_df.mean() * 100
        fig = go.Figure()
        fig.add_trace(go.Bar(x=classes, y=rel_mean_vals,
                             marker_color=palette[:len(classes)],
                             text=[f"{v:.1f}%" for v in rel_mean_vals],
                             textposition="outside"))
        fig.update_layout(title="Mean Relative Abundance (%) by Class",
                          xaxis_title="Class",
                          yaxis_title="Mean Relative Abundance (%)",
                          template="plotly_white")
    figs.append(("mean_relative_abundance", "Mean relative abundance", fig))

    # 4. Normalized stacked bar
    if has_group:
        prop_df = df.groupby("Group")[classes].sum()
        prop_df = prop_df.div(prop_df.sum(axis=1), axis=0).fillna(0)
        x = prop_df.index
    else:
        prop_df = rel_df
        x = df["Image"]
    fig = go.Figure()
    for i, cls in enumerate(classes):
        fig.add_trace(go.Bar(
            x=x, y=prop_df[cls] * 100, name=cls,
            marker_color=palette[i % len(palette)],
            hovertemplate=f"%{{y:.2f}}% {cls}<extra></extra>"))
    fig.update_layout(barmode="stack",
                      title="Normalized Stacked Bar Plot (Class Composition)",
                      xaxis_title="Image/Group", yaxis_title="%",
                      template="plotly_white")
    figs.append(("stacked_composition", "Class composition (stacked)", fig))

    # 5. Heatmaps
    def clustered_heatmap(values_df, labels, colorscale, title, xtitle):
        labels = list(labels)
        if len(values_df) > 1:
            order = leaves_list(linkage(values_df.values, method="ward",
                                        metric="euclidean"))
            labels = [labels[i] for i in order]
            values_df = values_df.iloc[order, :]
        f = go.Figure(data=go.Heatmap(
            z=values_df.values.T, x=labels, y=values_df.columns,
            colorscale=colorscale, colorbar=dict(title="Rel. Abundance"),
            zmin=0, zmax=1))
        f.update_layout(title=title, xaxis_title=xtitle, yaxis_title="Class",
                        template="plotly_white")
        return f

    if not has_group:
        figs.append(("heatmap_per_image", "Heatmap per image", clustered_heatmap(
            df[classes].div(df[classes].sum(axis=1).replace(0, 1), axis=0),
            df["Image"].astype(str).tolist(), "Plasma",
            "Heatmap of Morphotype Distribution per Image "
            "(Relative Abundance, Clustered)", "Image (clustered)")))
    else:
        grp_prop = df.groupby("Group")[classes].mean()
        grp_rel = grp_prop.div(grp_prop.sum(axis=1), axis=0).fillna(0)
        figs.append(("heatmap_per_group", "Heatmap per group", clustered_heatmap(
            grp_rel, grp_rel.index.astype(str), "Viridis",
            "Heatmap of Group-wise Morphotype Distribution (Clustered)",
            "Group (clustered)")))
        rel_img = df[classes].div(df[classes].sum(axis=1).replace(0, 1),
                                  axis=0).fillna(0)
        labels = [f"{g}_{i}" for g, i in zip(df["Group"], df["Image"])]
        figs.append(("heatmap_per_image", "Heatmap per image", clustered_heatmap(
            rel_img, labels, "Plasma",
            "Heatmap of Morphotype Distribution per Image (Clustered)",
            "Image (clustered)")))
    return figs


def plot_stem(analysis_name: str, plot_key: str) -> str:
    """`<analysis>_<plot>` - the analysis name is always part of the name."""
    return f"{safe_name(analysis_name)}_{plot_key}"


def plot_file_name(analysis_name: str, plot_key: str, ext: str = "html") -> str:
    return f"{plot_stem(analysis_name, plot_key)}.{ext}"


_PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
 body {{ font-family: sans-serif; margin: 0; }}
 #bar {{ position: sticky; top: 0; z-index: 10; background: #388659; color: #fff;
        padding: 8px 14px; display: flex; gap: 12px; align-items: center; }}
 #bar button, #bar select {{ font-size: 14px; padding: 4px 10px; }}
 section {{ padding: 6px 14px; border-bottom: 1px solid #ddd; }}
</style></head><body>
<div id="bar"><strong>{title}</strong>
 <select id="fmt"><option>png</option><option>svg</option><option>jpeg</option><option>webp</option></select>
 <button id="dlall">Download all plots</button><span id="status"></span></div>
{blocks}
<script>
const PLOTS = {plots_json};
document.getElementById("dlall").addEventListener("click", async () => {{
  const fmt = document.getElementById("fmt").value;
  const status = document.getElementById("status");
  for (let i = 0; i < PLOTS.length; i++) {{
    status.textContent = "Saving " + (i + 1) + " / " + PLOTS.length + " ...";
    const url = await Plotly.toImage(document.getElementById(PLOTS[i].id),
                                     {{format: fmt, width: 1400, height: 800, scale: 2}});
    const a = document.createElement("a");
    a.href = url; a.download = PLOTS[i].file + "." + fmt;
    document.body.appendChild(a); a.click(); a.remove();
    await new Promise(r => setTimeout(r, 500));
  }}
  status.textContent = "Done (" + PLOTS.length + " files, check your Downloads folder)";
}});
</script></body></html>
"""


def combined_html(figs: List[NamedFigure], analysis_name: str) -> str:
    """One page with every plot and a 'Download all plots' button.

    Plotly's JavaScript is embedded once, so the page also works offline.
    """
    blocks, plots = [], []
    for n, (key, title, fig) in enumerate(figs):
        div_id = f"plot_{key}"
        body = fig.to_html(include_plotlyjs=True if n == 0 else False,
                           full_html=False, div_id=div_id)
        blocks.append(f"<section><!-- {_html.escape(title)} -->{body}</section>")
        plots.append({"id": div_id,
                      "file": plot_stem(analysis_name, key)})
    return _PAGE.format(title=_html.escape(analysis_name or "TU_MyCo-Vision plots"),
                        blocks="\n".join(blocks),
                        plots_json=json.dumps(plots))


def export_figures(figs: List[NamedFigure], out_dir, analysis_name: str) -> List[Path]:
    """Write one HTML file per plot plus a combined page.

    File names: ``<analysis>_<plot>.html`` and ``<analysis>_all_plots.html``.
    Returns the written paths.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    written: List[Path] = []
    for key, _title, fig in figs:
        path = out_dir / plot_file_name(analysis_name, key)
        # 'directory' writes plotly.min.js once next to the files (works offline)
        fig.write_html(str(path), include_plotlyjs="directory", full_html=True)
        written.append(path)
    combined = out_dir / plot_file_name(analysis_name, "all_plots")
    combined.write_text(combined_html(figs, analysis_name), encoding="utf-8")
    written.append(combined)
    return written
