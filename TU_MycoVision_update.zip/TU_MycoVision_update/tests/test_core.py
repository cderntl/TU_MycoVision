import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from myco_core import (
    CLASSES_ALL, CLASSES_YOLO_ORDER, CORRECT_ALL, GroupDef, assign_groups, build_counts_frame,
    canonical_to_yolo_names, compile_pattern, discover_image_folders,
    discover_label_files, merge_excluded, parse_label_file,
    unique_root_labels, validate_patterns, yolo_to_canonical_names,
)


def touch(path: Path, text=""):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


# ── image discovery ────────────────────────────────────────────────
def make_tree(tmp_path):
    touch(tmp_path / "exp" / "a.png")
    touch(tmp_path / "exp" / "ctrl" / "c1.jpg")
    touch(tmp_path / "exp" / "ctrl" / "c2.JPG")
    touch(tmp_path / "exp" / "heat" / "deep" / "h1.tif")
    touch(tmp_path / "exp" / "heat" / "notes.csv")
    touch(tmp_path / "exp" / ".hidden" / "x.png")
    return tmp_path / "exp"


def test_flat_discovery_ignores_subfolders(tmp_path):
    root = make_tree(tmp_path)
    leaves = discover_image_folders([root], recursive=False)
    assert [l.folder for l in leaves] == [root]
    assert [p.name for p in leaves[0].images] == ["a.png"]


def test_recursive_discovery(tmp_path):
    root = make_tree(tmp_path)
    leaves = discover_image_folders([root], recursive=True)
    rels = [l.rel.as_posix() for l in leaves]
    assert rels == [".", "ctrl", "heat/deep"]      # hidden + empty folders skipped
    assert sum(len(l.images) for l in leaves) == 4


def test_recursive_skips_old_prediction_output(tmp_path):
    root = make_tree(tmp_path)
    touch(root / "run1" / "pic.png")
    touch(root / "run1" / "labels" / "pic.txt", "0 0.5 0.5 0.1 0.1\n")
    rels = [l.rel.as_posix() for l in discover_image_folders([root], True)]
    assert "run1" not in rels


def test_nested_roots_not_duplicated(tmp_path):
    root = make_tree(tmp_path)
    leaves = discover_image_folders([root, root / "ctrl"], True)
    folders = [l.folder for l in leaves]
    assert len(folders) == len(set(folders))


def test_unique_root_labels_disambiguate(tmp_path):
    a, b = tmp_path / "x" / "data", tmp_path / "y" / "data"
    a.mkdir(parents=True); b.mkdir(parents=True)
    labels = unique_root_labels([a, b])
    assert len(set(labels.values())) == 2


# ── label discovery / parsing ──────────────────────────────────────
def test_label_discovery_prefers_labels_dirs(tmp_path):
    touch(tmp_path / "run" / "labels" / "a.txt")
    touch(tmp_path / "run" / "sub" / "labels" / "b.txt")
    touch(tmp_path / "run" / "classes.txt")
    touch(tmp_path / "run" / "notes.txt")
    found = discover_label_files([tmp_path / "run"], recursive=True)
    assert [f.sample for f in found] == ["a", "sub/b"]


def test_label_discovery_flat_fallback(tmp_path):
    touch(tmp_path / "flat" / "a.txt")
    touch(tmp_path / "flat" / "b.txt")
    assert [f.sample for f in discover_label_files([tmp_path / "flat"])] == ["a", "b"]


def test_label_discovery_non_recursive_matches_old_behaviour(tmp_path):
    touch(tmp_path / "run" / "labels" / "a.txt")
    touch(tmp_path / "run" / "sub" / "labels" / "b.txt")
    found = discover_label_files([tmp_path / "run"], recursive=False)
    assert [f.sample for f in found] == ["a"]


def test_parse_label_file_counts_and_border_rule(tmp_path):
    # id 0 (C2) inside, id 0 at the border (skipped), id 4 at the border (kept,
    # border-exempt) -> canonical name looked up from the table
    p = touch(tmp_path / "x.txt",
              "0 0.5 0.5 0.2 0.2\n"
              "0 0.05 0.5 0.1 0.2\n"
              "4 0.05 0.5 0.1 0.2\n"
              "garbage line\n"
              "2 0.5 0.5 0.2 0.2 0.9\n")
    counts = dict(zip(CLASSES_ALL, parse_label_file(p)))
    assert counts["C2"] == 1
    assert counts[CLASSES_YOLO_ORDER[4]] == 1
    assert counts["C1"] == 1          # yolo id 2 -> C1
    assert sum(counts.values()) == 3


def test_build_counts_frame_layouts(tmp_path):
    a = touch(tmp_path / "r" / "labels" / "a.txt", "0 0.5 0.5 0.2 0.2\n")
    lf = discover_label_files([tmp_path / "r"])
    single = build_counts_frame([(lf[0], None)])
    assert list(single.columns)[0] == "Image" and "Group" not in single
    multi = build_counts_frame([(lf[0], "G1")])
    assert list(multi.columns)[-2:] == ["Group", "Image"]


def test_merge_excluded():
    import pandas as pd
    df = pd.DataFrame({"Image": ["a"], "C1": [1], "C2": [2], "C3-B": [4]})
    out = merge_excluded(df, ["C2", "C3-B", "nope"])
    assert out["Others"].tolist() == [6] and "C2" not in out


def test_name_order_roundtrip():
    names = [f"n{i}" for i in range(13)]
    assert yolo_to_canonical_names(canonical_to_yolo_names(names)) == names
    assert sorted(CORRECT_ALL) == list(range(13))


# ── group matching ─────────────────────────────────────────────────
def test_plain_wildcard_and_regex_patterns():
    assert compile_pattern("CTRL").search("exp/ctrl/img1")
    assert compile_pattern("ctrl*_01").search("exp/ctrl_a_01")
    assert not compile_pattern("ctrl*_01").search("exp/ctrl_a_02")
    assert compile_pattern("img?").search("img1") and not compile_pattern("img?").search("img")
    assert compile_pattern(r"re:^exp/h\d+").search("exp/h12/x")
    assert compile_pattern("a.b").search("a.b") and not compile_pattern("a.b").search("axb")


def test_group_from_row_defaults():
    assert GroupDef.from_row("", "ctrl, wt") == GroupDef("ctrl", ["ctrl", "wt"])
    assert GroupDef.from_row("Control", "") == GroupDef("Control", ["Control"])
    assert GroupDef.from_row("", "  ") is None


def test_validate_patterns_reports_bad_regex():
    assert validate_patterns([GroupDef("g", ["re:("])])
    assert not validate_patterns([GroupDef("g", ["ok"])])


def test_string_pointing_to_two_folders_makes_one_group():
    texts = ["exp/day1/ctrl/a", "exp/day2/ctrl/b", "exp/day1/heat/c"]
    res = assign_groups(texts, [GroupDef("Control", ["ctrl"]), GroupDef("Heat", ["heat"])])
    assert res.groups == {"Control": [0, 1], "Heat": [2]}
    assert not res.unmatched and not res.conflicts


def test_string_in_filenames_makes_group():
    texts = ["exp/all/WT_01", "exp/all/WT_02", "exp/all/KO_01", "exp/all/other"]
    res = assign_groups(texts, [GroupDef("WT", ["WT"]), GroupDef("KO", ["KO"])])
    assert res.groups["WT"] == [0, 1] and res.groups["KO"] == [2]
    assert res.unmatched == [3]


def test_conflict_policies():
    texts = ["exp/ctrl_heat/a", "exp/ctrl/b"]
    defs = [GroupDef("C", ["ctrl"]), GroupDef("H", ["heat"])]
    skip = assign_groups(texts, defs, "skip")
    assert skip.conflicts == {0: ["C", "H"]} and skip.groups == {"C": [1], "H": []}
    first = assign_groups(texts, defs, "first")
    assert first.groups == {"C": [0, 1], "H": []}


def test_rows_with_same_name_merge():
    res = assign_groups(["a1", "b1", "c1"],
                        [GroupDef("X", ["a"]), GroupDef("x", ["b"])])
    assert res.groups == {"X": [0, 1]} and res.unmatched == [2]
