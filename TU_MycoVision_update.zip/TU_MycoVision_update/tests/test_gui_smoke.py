"""Headless GUI tests (Qt 'offscreen' platform)."""
import importlib.util
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pytest

pytest.importorskip("PyQt5")
pytest.importorskip("plotly")
pytest.importorskip("scipy")

from PyQt5.QtCore import QCoreApplication, QSettings
from PyQt5.QtWidgets import QApplication, QDialog, QMessageBox


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    return app


@pytest.fixture(autouse=True)
def isolated_settings(tmp_path, monkeypatch):
    QSettings.setPath(QSettings.NativeFormat, QSettings.UserScope, str(tmp_path / "cfg"))
    QSettings.setPath(QSettings.IniFormat, QSettings.UserScope, str(tmp_path / "cfg"))
    # never block on message boxes
    monkeypatch.setattr(QMessageBox, "information", lambda *a, **k: 0)
    monkeypatch.setattr(QMessageBox, "critical", lambda *a, **k: 0)


def load_main():
    spec = importlib.util.spec_from_file_location(
        "myco_main", ROOT / "TU_MyCo-Vision_v1_source_code.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def make_results(tmp_path):
    """results/{ctrl_day1,ctrl_day2,heat_day1}/labels/*.txt"""
    root = tmp_path / "results"
    line_c2 = "0 0.5 0.5 0.2 0.2\n"
    line_c1 = "2 0.4 0.4 0.1 0.1\n"
    for folder, n in (("ctrl_day1", 3), ("ctrl_day2", 2), ("heat_day1", 2)):
        for i in range(n):
            p = root / folder / "labels" / f"img{i}.txt"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(line_c2 * (i + 1) + line_c1)
    return root


def wait(window, qapp, timeout_ms=60000):
    import time
    t0 = time.time()
    while window._active_thread is not None and (time.time() - t0) * 1000 < timeout_ms:
        qapp.processEvents()
        time.sleep(0.02)
    qapp.processEvents()
    assert window._active_thread is None, "task did not finish"


@pytest.fixture
def window(qapp):
    mod = load_main()
    w = mod.MycoVisionApp()
    w._build_main_ui()
    w._mod = mod
    yield w
    w.close()


def test_main_ui_has_new_widgets(window):
    assert window.log_panel is not None
    assert window._input_list.recursive() is True
    assert window._analysis_tabs.count() == 3


def test_log_panel_handles_progress_bar_carriage_returns(window, qapp):
    from myco_qtutils import BUS
    BUS.message.emit("line one\n10%\r50%\r100%\ndone\n")
    qapp.processEvents()
    assert window.log_panel.text.toPlainText().splitlines()[-3:] == ["line one", "100%", "done"] \
        or "100%" in window.log_panel.text.toPlainText()
    assert "10%" not in window.log_panel.text.toPlainText()


def test_folder_list_multi_add_dedupe_and_persist(window, tmp_path, qapp):
    from myco_qtutils import FolderListWidget
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir(); b.mkdir()
    w = FolderListWidget("t_persist", "pick")
    w.add_folders([str(a), str(b), str(a), str(tmp_path / "missing")])
    assert w.folders() == [str(a), str(b)]
    w.recursive_cb.setChecked(False)
    again = FolderListWidget("t_persist", "pick")
    assert again.folders() == [str(a), str(b)] and again.recursive() is False


def test_last_directory_is_remembered(tmp_path):
    from myco_qtutils import last_dir, remember_dir
    d = tmp_path / "deep" / "pick"
    d.mkdir(parents=True)
    remember_dir("k", str(d))
    assert last_dir("k") == str(d)
    d.rmdir()                                     # folder vanished -> nearest parent
    assert last_dir("k") == str(d.parent)


def test_single_group_analysis_recursive_and_auto_plots(window, qapp, tmp_path):
    results = make_results(tmp_path)
    out = tmp_path / "out"
    window.single_group_folder = str(results)
    window._analysis_out["sg"] = str(out)
    window._sg_name_entry.setText("Run A")
    window.run_single_group_analysis_threaded()
    wait(window, qapp)
    import pandas as pd
    df = pd.read_csv(out / "Run A_rawdata.csv")
    assert len(df) == 7 and "Group" not in df
    assert set(df["Image"]) >= {"ctrl_day1/img0", "heat_day1/img1"}
    plots = sorted(p.name for p in (out / "Run_A_plots").glob("*.html"))
    assert "Run_A_all_plots.html" in plots and "Run_A_absolute_counts.html" in plots
    assert window.last_analysis_csv.endswith("Run A_rawdata.csv")


def test_multi_group_uses_folder_names(window, qapp, tmp_path):
    results = make_results(tmp_path)
    out = tmp_path / "out"
    window._mg_folders.add_folders([str(results / "ctrl_day1"), str(results / "heat_day1")])
    window._analysis_out["mg"] = str(out)
    window.run_multi_group_analysis_threaded()
    wait(window, qapp)
    import pandas as pd
    df = pd.read_csv(out / "MultiAnalysis_rawdata.csv")
    assert sorted(df["Group"].unique()) == ["ctrl_day1", "heat_day1"]
    assert any((out / "MultiAnalysis_plots").glob("MultiAnalysis_heatmap_per_group.html"))


def test_custom_groups_need_approval(window, qapp, tmp_path, monkeypatch):
    results = make_results(tmp_path)
    out = tmp_path / "out"
    window._cg_folders.add_folders([str(results)])
    window._analysis_out["cg"] = str(out)
    table = window._cg_table.table
    table.item(0, 0).setText("Control");  table.item(0, 1).setText("ctrl")
    table.item(1, 0).setText("");         table.item(1, 1).setText("heat*day1")

    # 1) user cancels in the preview -> nothing runs
    monkeypatch.setattr(window._mod.GroupPreviewDialog, "exec_", lambda self: QDialog.Rejected)
    window.run_custom_group_analysis_threaded()
    assert window._active_thread is None
    assert not (out / "CustomGroupAnalysis_rawdata.csv").exists()

    # 2) user approves -> runs; ctrl_day1 + ctrl_day2 (two folders) form one group
    shown = {}
    def approve(self):
        shown["ok"] = self.ok_btn.isEnabled()
        return QDialog.Accepted
    monkeypatch.setattr(window._mod.GroupPreviewDialog, "exec_", approve)
    window.run_custom_group_analysis_threaded()
    wait(window, qapp)
    assert shown["ok"]
    import pandas as pd
    df = pd.read_csv(out / "CustomGroupAnalysis_rawdata.csv")
    assert df.groupby("Group").size().to_dict() == {"Control": 5, "heat*day1": 2}


def test_exclusion_creates_excluded_csv_and_plots(window, qapp, tmp_path):
    results = make_results(tmp_path)
    out = tmp_path / "out"
    window.single_group_folder = str(results)
    window._analysis_out["sg"] = str(out)
    window._excl_checkboxes[0].setChecked(True)          # C1
    window.run_single_group_analysis_threaded()
    wait(window, qapp)
    import pandas as pd
    ex = pd.read_csv(out / "SingleAnalysis_excluded.csv")
    assert "Others" in ex.columns and "C1" not in ex.columns
    assert (out / "SingleAnalysis_plots" / "SingleAnalysis_excluded_absolute_counts.html").exists()


def test_download_all_plots(window, qapp, tmp_path, monkeypatch):
    results = make_results(tmp_path)
    window.single_group_folder = str(results)
    window._analysis_out["sg"] = str(tmp_path / "out")
    window.run_single_group_analysis_threaded()
    wait(window, qapp)
    target = tmp_path / "dl"; target.mkdir()
    monkeypatch.setattr(window._mod, "ask_directory", lambda *a, **k: str(target))
    window.dashboard_download_all_plots()
    files = [p.name for p in (target / "SingleAnalysis_plots").glob("*.html")]
    assert files and all(f.startswith("SingleAnalysis_") for f in files)


def test_no_double_start(window, qapp, tmp_path):
    results = make_results(tmp_path)
    window.single_group_folder = str(results)
    window._analysis_out["sg"] = str(tmp_path / "out")
    window.run_single_group_analysis_threaded()
    first = window._active_thread
    window.run_single_group_analysis_threaded()       # ignored while busy
    assert window._active_thread is first
    wait(window, qapp)


def test_light_theme_is_forced_even_on_dark_desktop(qapp):
    """A dark system palette must not leak into the app (unreadable text)."""
    from PyQt5.QtGui import QColor, QPalette
    mod = load_main()
    dark = QPalette()
    dark.setColor(QPalette.Window, QColor("#2b2b2b"))
    dark.setColor(QPalette.Base, QColor("#1e1e1e"))
    dark.setColor(QPalette.WindowText, QColor("#eeeeee"))
    qapp.setPalette(dark)
    mod.apply_app_theme(qapp, mod.make_app_font())
    pal = qapp.palette()
    assert pal.color(QPalette.Window).lightness() > 200
    assert pal.color(QPalette.Base).lightness() > 200
    assert pal.color(QPalette.WindowText).lightness() < 80
    assert pal.color(QPalette.Text).lightness() < 80


def test_buttons_are_wide_and_tall_enough_for_their_text(window, qapp):
    from PyQt5.QtGui import QFontMetrics
    from PyQt5.QtWidgets import QPushButton
    for btn in window.findChildren(QPushButton):
        if not btn.text():
            continue
        fm = QFontMetrics(btn.font())
        assert btn.minimumHeight() >= fm.height(), btn.text()
        assert btn.minimumWidth() >= fm.horizontalAdvance(btn.text()) * 0.8, btn.text()
