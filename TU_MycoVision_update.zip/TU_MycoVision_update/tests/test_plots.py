import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import pytest

pytest.importorskip("plotly")
pytest.importorskip("scipy")

from myco_plots import (analysis_name_from_csv, build_figures, combined_html,
                        export_figures, plot_file_name, safe_name)


def single_df():
    return pd.DataFrame({"Image": ["a", "b", "c"], "C1": [3, 0, 5],
                         "C2": [1, 4, 0], "C3-B": [0, 2, 2]})


def multi_df():
    d = single_df()
    d["Group"] = ["ctrl", "ctrl", "heat"]
    return d


def test_names():
    assert safe_name("My run: 1/2") == "My_run_1_2"
    assert safe_name("   ") == "analysis"
    assert analysis_name_from_csv("/x/MyRun_rawdata.csv") == "MyRun"
    assert analysis_name_from_csv("/x/MyRun_excluded.csv") == "MyRun_excluded"
    assert plot_file_name("A b", "relative_abundance") == "A_b_relative_abundance.html"


@pytest.mark.parametrize("df,keys", [
    (single_df(), ["absolute_counts", "relative_abundance", "mean_relative_abundance",
                   "stacked_composition", "heatmap_per_image"]),
    (multi_df(), ["absolute_counts", "relative_abundance", "mean_relative_abundance",
                  "stacked_composition", "heatmap_per_group", "heatmap_per_image"]),
])
def test_build_figures(df, keys):
    assert [k for k, _, _ in build_figures(df)] == keys


def test_export_names_contain_analysis_and_page_has_download_all(tmp_path):
    figs = build_figures(multi_df())
    written = export_figures(figs, tmp_path, "Run 7")
    names = sorted(p.name for p in written)
    assert all(n.startswith("Run_7_") for n in names)
    assert "Run_7_all_plots.html" in names
    assert (tmp_path / "plotly.min.js").exists()
    page = (tmp_path / "Run_7_all_plots.html").read_text(encoding="utf-8")
    assert "Download all plots" in page and "Run_7_absolute_counts" in page


def test_single_image_does_not_crash_clustering():
    df = single_df().iloc[:1]
    assert build_figures(df)
