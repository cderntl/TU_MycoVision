# ==================== TU_MyCo-Vision v2 (PyQt5) ====================
#
# Requirements: see environment.yml (installers create the environment).
# Helper modules next to this file: myco_core.py, myco_plots.py, myco_qtutils.py
#
# Written by:
# Kartik Deopujari
# Matthias Schmal
# Good coding vibes
# PyQt5 refactor: automated refactoring pass
# ====================================================================

import sys
import os
import time
import csv
import threading
import tempfile
import webbrowser
from pathlib import Path

# Make the helper modules importable however the script is started.
sys.path.insert(0, str(Path(__file__).resolve().parent))

# ── PyQt5 imports ──────────────────────────────────────────────────
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QGridLayout, QLabel, QPushButton, QCheckBox, QLineEdit, QSlider,
    QTabWidget, QFileDialog, QMessageBox, QProgressBar, QScrollArea,
    QFrame, QSplitter, QScrollBar, QDialog, QDialogButtonBox,
    QTreeWidget, QTreeWidgetItem, QHeaderView, QSizePolicy, QTextEdit,
    QGroupBox, QSpacerItem, QComboBox,
)
from PyQt5.QtCore import (
    Qt, QThread, pyqtSignal, QSize, QTimer, QRect, QPoint,
)
from PyQt5.QtGui import (
    QPixmap, QImage, QFont, QColor, QPainter, QPen, QBrush,
    QFontMetrics, QCursor, QPalette,
)

# ── Project helpers (no heavy dependencies) ─────────────────────────
from myco_core import (
    CLASSES_ALL, CLASSES_YOLO_ORDER, CORRECT_ALL, IMAGE_EXTENSIONS, EPSILON,
    GroupDef, LabelFile, apply_custom_names, assign_groups, build_counts_frame,
    canonical_to_yolo_names, discover_image_folders, discover_label_files,
    is_image, merge_excluded, validate_patterns, yolo_to_canonical_names,
)
from myco_qtutils import (
    BUS, FolderListWidget, GroupPreviewDialog, GroupTable, LogPanel,
    ask_directory, hook_ultralytics_logging, last_dir, log, redirect_output,
    remember_dir, settings,
)

# ── Deferred heavy imports (loaded after splash) ────────────────────
pd = None
np = None
cv2 = None

# ── Colour palette (matches original pastel green/yellow theme) ─────
BG_MAIN     = "#f5f7f0"
BG_BLOCK    = "#eafaf1"
BORDER      = "#bbded6"
GREEN_DARK  = "#388659"
GREEN_MED   = "#21a179"
GREEN_LIGHT = "#d2f8d2"
BLUE_DARK   = "#406882"
BLUE_LIGHT  = "#1eb2e6"
YELLOW      = "#fae588"
TEXT_GREEN  = "#457267"
TEXT_DARK   = "#222222"
WHITE       = "#ffffff"
PATH_BG     = "#f7fff7"
PROGRESS_BLUE = "#00589C"


# ── Stylesheet ──────────────────────────────────────────────────────
GLOBAL_STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: transparent;
    font-size: 10pt;
    color: {TEXT_DARK};
}}
QMainWindow, QDialog {{
    background-color: {BG_MAIN};
}}
QListWidget, QPlainTextEdit, QTextEdit, QTableWidget, QComboBox,
QComboBox QAbstractItemView {{
    background-color: {WHITE};
    color: {TEXT_DARK};
}}
QToolTip {{
    background-color: #fffff0;
    color: {TEXT_DARK};
    border: 1px solid {BORDER};
}}
QTabWidget::pane {{
    border: 1px solid {BORDER};
    background: rgba(245, 247, 240, 210);
}}
QTabBar::tab {{
    background: #daf0e8;
    color: {GREEN_DARK};
    padding: 0.5em 1.6em;
    border: 1px solid {BORDER};
    border-bottom: none;
    font-weight: bold;
    min-width: 6em;
}}
QTabBar::tab:selected {{
    background: {BG_BLOCK};
    color: {BLUE_DARK};
}}
QPushButton {{
    border-radius: 6px;
    padding: 0.4em 0.9em;
    font-weight: bold;
    color: white;
    background-color: {GREEN_MED};
    border: none;
}}
QPushButton:hover {{
    opacity: 0.85;
}}
QPushButton:pressed {{
    background-color: {GREEN_DARK};
}}
QLineEdit {{
    background: {WHITE};
    border: 1px solid {BORDER};
    border-radius: 4px;
    padding: 0.2em 0.4em;
}}
QCheckBox {{
    spacing: 0.4em;
    font-size: 10pt;
}}
QCheckBox::indicator {{
    width: 1em;
    height: 1em;
}}
QCheckBox::indicator:unchecked {{
    border: 1px solid #aaa;
    border-radius: 3px;
    background: white;
}}
QCheckBox::indicator:checked {{
    border: 1px solid {GREEN_DARK};
    border-radius: 3px;
    background: {GREEN_MED};
}}
QProgressBar {{
    border: 1px solid {BORDER};
    border-radius: 5px;
    background: #dcdcdc;
    min-height: 12px;
    max-height: 18px;
    text-align: center;
}}
QProgressBar::chunk {{
    background-color: {PROGRESS_BLUE};
    border-radius: 4px;
}}
QSlider::groove:horizontal {{
    height: 6px;
    background: #dcdcdc;
    border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background: {GREEN_MED};
    border: 1px solid {GREEN_DARK};
    width: 14px;
    height: 14px;
    border-radius: 7px;
    margin: -4px 0;
}}
QSlider::sub-page:horizontal {{
    background: {GREEN_MED};
    border-radius: 3px;
}}
QScrollBar:horizontal {{
    height: 10px;
    background: #f0f0f0;
}}
QScrollBar::handle:horizontal {{
    background: #aaa;
    border-radius: 5px;
    min-width: 20px;
}}
QLabel#path_label {{
    background: {PATH_BG};
    border: 1px solid {BORDER};
    border-radius: 4px;
    color: {TEXT_GREEN};
    padding: 0.2em 0.4em;
    font-size: 9pt;
}}
QGroupBox {{
    background: {BG_BLOCK};
    border: 1px solid {BORDER};
    border-radius: 6px;
    margin-top: 0.6em;
    padding: 0.5em;
    font-weight: bold;
    font-size: 10pt;
    color: {GREEN_DARK};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
}}
QTreeWidget {{
    border: 1px solid {BORDER};
    background: white;
    alternate-background-color: #f0fdf4;
    font-size: 9pt;
}}
QHeaderView::section {{
    background: {BG_BLOCK};
    padding: 4px;
    border: 1px solid {BORDER};
    font-weight: bold;
    font-size: 9pt;
}}
"""


# ── Theme ───────────────────────────────────────────────────────────
# The look is designed on a light background. On a dark desktop theme Qt hands
# us dark palette colours, so the transparent panels turn dark and the dark
# text disappears. We therefore always set our own light palette.
def apply_app_theme(app, font=None):
    app.setStyle("Fusion")
    pal = QPalette()
    roles = {
        QPalette.Window: BG_MAIN, QPalette.WindowText: TEXT_DARK,
        QPalette.Base: WHITE, QPalette.AlternateBase: "#f0fdf4",
        QPalette.Text: TEXT_DARK, QPalette.Button: "#e8f3ee",
        QPalette.ButtonText: TEXT_DARK, QPalette.ToolTipBase: "#fffff0",
        QPalette.ToolTipText: TEXT_DARK, QPalette.Highlight: GREEN_MED,
        QPalette.HighlightedText: WHITE, QPalette.Link: BLUE_DARK,
        QPalette.BrightText: WHITE, QPalette.PlaceholderText: "#7a8a84",
    }
    for role, colour in roles.items():
        pal.setColor(role, QColor(colour))
    for role in (QPalette.WindowText, QPalette.Text, QPalette.ButtonText):
        pal.setColor(QPalette.Disabled, role, QColor("#9aa5a0"))
    app.setPalette(pal)
    if font is not None:
        app.setFont(font)


def make_app_font() -> QFont:
    """10 pt font; Qt uses the first family of the list that is installed."""
    font = QFont()
    font.setFamilies(["Segoe UI", "Helvetica Neue", "Noto Sans", "Cantarell",
                      "Ubuntu", "DejaVu Sans", "Arial"])
    font.setPointSize(10)
    font.setStyleStrategy(QFont.PreferAntialias)
    return font


def resource_path(relative: str) -> Path:
    """Resolve resource paths (model, images) next to this script.

    Uses the script's own folder, not the current working directory, so a
    desktop shortcut works from anywhere. PyInstaller builds still work.
    """
    try:
        base = Path(sys._MEIPASS)
    except AttributeError:
        base = Path(__file__).resolve().parent
    return base / relative


# ═══════════════════════════════════════════════════════════════════
# Worker thread base
# ═══════════════════════════════════════════════════════════════════
class WorkerThread(QThread):
    progress = pyqtSignal(float)   # 0.0 – 1.0
    status   = pyqtSignal(str)     # short text shown inside the progress bar
    finished = pyqtSignal(str)     # success message
    error    = pyqtSignal(str)     # error message


# ═══════════════════════════════════════════════════════════════════
# Custom Class Names Popup Dialog
# ═══════════════════════════════════════════════════════════════════
class CustomClassNamesDialog(QDialog):
    """Popup for setting custom class name strings for each of the 13 classes.

    Names are ordered by YOLO class ID (0–12), exactly as stored in the model
    (checked against ``YOLO("TU_MyCo-Vision.pt").names``):
      ID 0→C2, 1→C5, 2→C1, 3→C4, 4→C6, 5→C11, 6→C9,
         7→C2-B, 8→C3-B, 9→C8, 10→C7-E, 11→C7-F, 12→C7-G
    This matches the order used by draw_yolo_overlays and the label files.
    """

    # Ordered by YOLO class ID 0–12
    DEFAULT_NAMES = list(CLASSES_YOLO_ORDER)

    def __init__(self, parent=None, current_names=None, enabled=False):
        super().__init__(parent)
        self.setWindowTitle("Custom Class Names")
        self.setMinimumWidth(420)
        self.setStyleSheet(GLOBAL_STYLESHEET)

        layout = QVBoxLayout(self)

        # Enable toggle
        self.enable_cb = QCheckBox("Enable custom class names")
        self.enable_cb.setChecked(enabled)
        self.enable_cb.setStyleSheet(f"font-weight: bold; color: {GREEN_DARK};")
        self.enable_cb.toggled.connect(self._on_toggle)
        layout.addWidget(self.enable_cb)

        info = QLabel(
            "If enabled: 'Save images' is forced OFF for the prediction run.\n"
            "Custom names are used in all outputs: CSV columns, chart labels,\n"
            "and bounding-box overlays. Names below are listed by YOLO class ID\n"
            "(the order the model uses internally in its label files)."
        )
        info.setStyleSheet(f"color: {BLUE_DARK}; font-size: 11px; padding: 4px 0;")
        info.setWordWrap(True)
        layout.addWidget(info)

        # Grid of name entries
        grid = QGridLayout()
        grid.setSpacing(6)
        self.entries = []
        init_names = current_names if current_names else self.DEFAULT_NAMES[:]
        for i, (dname, cname) in enumerate(zip(self.DEFAULT_NAMES, init_names)):
            row = i // 2
            col_base = (i % 2) * 3
            grid.addWidget(QLabel(f"{dname}:"), row, col_base)
            entry = QLineEdit(cname)
            entry.setMinimumWidth(90)
            entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            entry.setToolTip(f"Custom label for class {dname}")
            grid.addWidget(entry, row, col_base + 1)
            self.entries.append(entry)
        layout.addLayout(grid)

        # Buttons
        bbox = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bbox.accepted.connect(self.accept)
        bbox.rejected.connect(self.reject)
        layout.addWidget(bbox)

        self._on_toggle(enabled)

    def _on_toggle(self, state):
        for e in self.entries:
            e.setEnabled(state)

    def get_values(self):
        """Return (enabled: bool, names: list[str])"""
        names = [e.text().strip() or self.DEFAULT_NAMES[i]
                 for i, e in enumerate(self.entries)]
        return self.enable_cb.isChecked(), names


# ═══════════════════════════════════════════════════════════════════
# Class Reference Popup
# ═══════════════════════════════════════════════════════════════════
class ClassReferenceDialog(QDialog):
    def __init__(self, parent=None, img_path=None):
        super().__init__(parent)
        self.setWindowTitle("Morphotype Class Reference")
        self.resize(800, 600)
        self.setStyleSheet(GLOBAL_STYLESHEET)
        layout = QVBoxLayout(self)
        self._lbl = QLabel(alignment=Qt.AlignCenter)
        self._lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self._lbl)
        self._orig_pixmap = None
        if img_path and Path(img_path).exists():
            self._orig_pixmap = QPixmap(str(img_path))
            self._update_image()
        else:
            self._lbl.setText("Reference image not found.")
        btn = QPushButton("Close")
        btn.clicked.connect(self.accept)
        btn.setStyleSheet(f"background:{GREEN_MED}; color:white; padding:6px 20px;")
        layout.addWidget(btn, alignment=Qt.AlignCenter)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_image()

    def _update_image(self):
        if self._orig_pixmap:
            scaled = self._orig_pixmap.scaled(
                self._lbl.width() - 20, self._lbl.height() - 20,
                Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self._lbl.setPixmap(scaled)


# ═══════════════════════════════════════════════════════════════════
# CSV Table Dialog
# ═══════════════════════════════════════════════════════════════════
class CSVTableDialog(QDialog):
    def __init__(self, parent, df):
        super().__init__(parent)
        self.setWindowTitle("CSV Data Table")
        self.resize(1000, 600)
        self.setStyleSheet(GLOBAL_STYLESHEET)
        self._df = df
        layout = QVBoxLayout(self)
        tree = QTreeWidget()
        tree.setHeaderLabels(list(df.columns))
        tree.header().setSectionResizeMode(QHeaderView.Interactive)
        tree.setAlternatingRowColors(True)
        for _, row in df.iterrows():
            item = QTreeWidgetItem([str(v) for v in row])
            tree.addTopLevelItem(item)
        layout.addWidget(tree)
        btn = QPushButton("Export CSV")
        btn.setStyleSheet(f"background:{BLUE_DARK}; color:white;")
        btn.clicked.connect(self._export)
        layout.addWidget(btn, alignment=Qt.AlignRight)

    def _export(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Export CSV", "", "CSV Files (*.csv)")
        if path:
            self._df.to_csv(path, index=False)
            QMessageBox.information(self, "Exported", f"CSV exported to:\n{path}")


# ═══════════════════════════════════════════════════════════════════
# Bounding Box Overlay (pure cv2, uses YOLO .txt labels)
# ═══════════════════════════════════════════════════════════════════
def draw_yolo_overlays(image_dir: Path, label_dir: Path, output_dir: Path,
                       custom_names: list, class_color_map: dict = None):
    """
    Read YOLO label .txt files from label_dir, draw bounding boxes with
    custom_names on original images from image_dir, write annotated copies
    to output_dir. Does NOT rely on ultralytics rendering.

    Args:
        image_dir:       folder with original images
        label_dir:       folder with YOLO .txt label files
        output_dir:      destination folder for annotated images
        custom_names:    list of 13 strings, indexed by YOLO class id
        class_color_map: optional dict class_id->BGR tuple; auto-generated if None
    """
    import cv2 as _cv2

    output_dir.mkdir(parents=True, exist_ok=True)

    # Build a colour palette (one per class)
    NUM_CLASSES = len(custom_names)
    if class_color_map is None:
        import colorsys
        class_color_map = {}
        for cid in range(NUM_CLASSES):
            h = cid / max(NUM_CLASSES, 1)
            r, g, b = colorsys.hsv_to_rgb(h, 0.85, 0.95)
            class_color_map[cid] = (int(b * 255), int(g * 255), int(r * 255))

    label_files = list(label_dir.glob("*.txt"))
    if not label_files:
        return 0

    written = 0
    for lf in label_files:
        # Find matching image (any supported extension)
        img_path = None
        for ext in IMAGE_EXTENSIONS:
            candidate = image_dir / (lf.stem + ext)
            if candidate.exists():
                img_path = candidate
                break
        if img_path is None:
            continue

        img = _cv2.imread(str(img_path))
        if img is None:
            continue
        ih, iw = img.shape[:2]

        with open(lf, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.strip().split()
                if len(parts) < 5:
                    continue
                try:
                    cid = int(parts[0])
                    cx, cy, bw, bh = map(float, parts[1:5])
                except ValueError:
                    continue
                if cid < 0 or cid >= NUM_CLASSES:
                    continue

                x1 = int((cx - bw / 2) * iw)
                y1 = int((cy - bh / 2) * ih)
                x2 = int((cx + bw / 2) * iw)
                y2 = int((cy + bh / 2) * ih)
                x1, y1 = max(0, x1), max(0, y1)
                x2, y2 = min(iw - 1, x2), min(ih - 1, y2)

                color = class_color_map.get(cid, (0, 255, 0))
                _cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)

                label_text = custom_names[cid] if cid < len(custom_names) else str(cid)
                font_scale = max(0.4, min(iw, ih) / 1000)
                thickness = max(1, int(font_scale * 2))
                (tw, th), baseline = _cv2.getTextSize(
                    label_text, _cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
                ty = max(y1 - 4, th + 4)
                _cv2.rectangle(img,
                               (x1, ty - th - baseline - 2),
                               (x1 + tw + 4, ty + baseline - 2),
                               color, -1)
                _cv2.putText(img, label_text, (x1 + 2, ty - 2),
                             _cv2.FONT_HERSHEY_SIMPLEX, font_scale,
                             (255, 255, 255), thickness, _cv2.LINE_AA)

        out_path = output_dir / img_path.name
        _cv2.imwrite(str(out_path), img)
        written += 1

    return written


# ═══════════════════════════════════════════════════════════════════
# Image Viewer Widget (replaces tkinter canvas-based viewer)
# ═══════════════════════════════════════════════════════════════════
class ZoomPanLabel(QLabel):
    """Image label with mouse-wheel zoom and click-drag pan."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(400, 300)
        self.setStyleSheet("background: white;")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._pil_img  = None
        self._zoom     = 1.0
        self._offset   = QPoint(0, 0)
        self._drag_pos = None
        self.setMouseTracking(True)

    def set_pil_image(self, pil_img):
        self._pil_img = pil_img
        self._fit_zoom()
        self._offset = QPoint(0, 0)
        self._render()

    def _fit_zoom(self):
        if self._pil_img is None:
            return
        iw, ih = self._pil_img.size
        sw, sh = self.width(), self.height()
        if iw == 0 or ih == 0:
            return
        self._zoom = min(sw / iw, sh / ih)

    def _render(self):
        if self._pil_img is None:
            self.clear()
            return
        iw, ih = self._pil_img.size
        sw, sh = max(self.width(), 1), max(self.height(), 1)
        nw = max(1, int(iw * self._zoom))
        nh = max(1, int(ih * self._zoom))
        resized = self._pil_img.resize((nw, nh), 1)  # LANCZOS=1 in Pillow>=10

        data = resized.convert("RGBA").tobytes("raw", "RGBA")
        qimg = QImage(data, nw, nh, QImage.Format_RGBA8888)
        pm = QPixmap.fromImage(qimg)

        canvas = QPixmap(sw, sh)
        canvas.fill(QColor("white"))
        painter = QPainter(canvas)

        # Clamped offset
        ox = self._offset.x()
        oy = self._offset.y()
        if nw <= sw:
            ox = (sw - nw) // 2
            self._offset.setX(0)
        else:
            ox = max(0, min(ox, nw - sw))
            self._offset.setX(ox)
            ox = -ox
        if nh <= sh:
            oy = (sh - nh) // 2
            self._offset.setY(0)
        else:
            oy = max(0, min(oy, nh - sh))
            self._offset.setY(oy)
            oy = -oy

        painter.drawPixmap(ox, oy, pm)

        # Zoom label
        fit = min(sw / iw, sh / ih) if iw and ih else 1.0
        painter.setPen(QColor(GREEN_DARK))
        painter.setFont(QFont("Arial", 10))
        painter.drawText(4, sh - 4, f"Zoom: {self._zoom / fit:.2f}x")
        painter.end()
        self.setPixmap(canvas)

    def wheelEvent(self, event):
        if self._pil_img is None:
            return
        iw, ih = self._pil_img.size
        sw, sh = max(self.width(), 1), max(self.height(), 1)
        fit = min(sw / iw, sh / ih) if iw and ih else 1.0
        delta = event.angleDelta().y()
        factor = 1.13 if delta > 0 else 0.88
        new_zoom = max(fit, min(self._zoom * factor, fit * 10))
        # zoom towards mouse position
        mx = event.pos().x()
        my = event.pos().y()
        ox = self._offset.x()
        oy = self._offset.y()
        rel_x = (ox + mx) / self._zoom
        rel_y = (oy + my) / self._zoom
        self._offset.setX(int(rel_x * new_zoom - mx))
        self._offset.setY(int(rel_y * new_zoom - my))
        self._zoom = new_zoom
        self._render()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_pos = event.pos()

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None and event.buttons() & Qt.LeftButton:
            delta = event.pos() - self._drag_pos
            self._offset -= delta
            self._drag_pos = event.pos()
            self._render()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._render()


# ═══════════════════════════════════════════════════════════════════
# Background-image central widget
# ═══════════════════════════════════════════════════════════════════
class BackgroundWidget(QWidget):
    """A QWidget that tiles/stretches a PNG image as its background.

    Drop this in as the central widget and all child widgets sit on
    top of the image automatically.

    Usage
    -----
    Set the path to your PNG via ``set_background(path)``.  The image
    is scaled to fill the widget while keeping its aspect ratio
    (Qt.KeepAspectRatioByExpanding), so it always covers the full
    window without distortion.  If you prefer a plain stretch, swap
    the AspectRatioMode for Qt.IgnoreAspectRatio.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._bg_pixmap: QPixmap | None = None

    def set_background(self, path: str) -> bool:
        """Load a PNG (or any Qt-supported image) as the background.

        Returns True on success, False if the file could not be loaded.
        """
        px = QPixmap(path)
        if px.isNull():
            return False
        self._bg_pixmap = px
        self.update()          # trigger a repaint
        return True

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(BG_MAIN))   # never show the desktop theme
        if self._bg_pixmap is None:
            return
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        scaled = self._bg_pixmap.scaled(
            self.size(),
            Qt.KeepAspectRatioByExpanding,
            Qt.SmoothTransformation,
        )
        # centre the (potentially oversized) scaled image
        x = (self.width()  - scaled.width())  // 2
        y = (self.height() - scaled.height()) // 2
        painter.drawPixmap(x, y, scaled)


# ═══════════════════════════════════════════════════════════════════
# Main Application Window
# ═══════════════════════════════════════════════════════════════════
class MycoVisionApp(QMainWindow):

    # Canonical display order of 13 classes — used for CSV columns, plots, checkboxes
    CLASS_NAMES_ORDERED = ["C1", "C2", "C2-B", "C3-B", "C5", "C8", "C9",
                           "C4", "C6", "C11", "C7-E", "C7-F", "C7-G"]
    # YOLO model class-ID order (id 0–12) — used for label file parsing and overlays
    YOLO_CLASS_NAMES    = list(CLASSES_YOLO_ORDER)
    # YOLO class id → index in CLASS_NAMES_ORDERED
    YOLO_TO_CLASS_INDEX = [2, 0, 7, 8, 1, 9, 6, 3, 4, 5, 10, 11, 12]
    # Display order for checkboxes (matches original UI)
    CLASS_DISPLAY_ORDER = ["C2", "C5", "C1", "C4", "C6", "C11",
                           "C9", "C2-B", "C3-B", "C8", "C7-E", "C7-F", "C7-G"]

    def __init__(self):
        super().__init__()
        self.setWindowTitle("TU_MyCo-Vision: Fungal Morphology Detector")
        # size from the font height and the screen, so large fonts / small
        # screens do not start with a clipped window
        scale = max(1.0, QFontMetrics(QApplication.font()).height() / 17.0)
        screen = QApplication.primaryScreen()
        avail = screen.availableGeometry() if screen else QRect(0, 0, 1400, 900)
        w = min(int(1300 * scale), int(avail.width() * 0.96))
        h = min(int(900 * scale), int(avail.height() * 0.94))
        self.resize(w, h)
        # no hard-coded minimum: the layouts report the smallest size at which
        # nothing overlaps, and Qt enforces it (also for big fonts)
        self.setStyleSheet(GLOBAL_STYLESHEET)

        # ── state ──────────────────────────────────────────────────
        self.output_folder  = ""
        self.confidence     = 0.20
        self.line_width     = 2
        self.agnostic_nms   = False
        self.show_output    = False
        self.analysis_name  = "Myco_Analysis"

        # 13 checkboxes (selected classes for detection)
        self.selected_classes = [False] * 13
        # 13 checkboxes (excluded classes for analysis)
        self.excluded_classes = [False] * 13

        # Custom class names feature
        self.custom_names_enabled = False
        self.custom_class_names   = self.CLASS_NAMES_ORDERED[:]  # 13 entries

        # Analysis
        self.single_group_folder           = ""
        self.single_analysis_name          = "SingleAnalysis"
        self.multi_analysis_name           = "MultiAnalysis"
        self.custom_analysis_name          = "CustomGroupAnalysis"
        self.last_analysis_csv             = None
        # output folder chosen on each analysis page: sg / mg / cg
        self._analysis_out                 = {"sg": "", "mg": "", "cg": ""}
        self._analysis_out_lbls            = {}
        self._active_thread                = None   # running background task

        # Dashboard
        self.orig_img_folder = ""
        self.pred_img_folder = ""
        self._dashboard_matches   = []
        self._dashboard_orig_map  = {}
        self._dashboard_pred_map  = {}
        self._dashboard_idx       = 0

        # ── Splash ─────────────────────────────────────────────────
        self._show_splash()

    # ──────────────────────────────────────────────────────────────
    # Splash Screen
    # ──────────────────────────────────────────────────────────────
    def _show_splash(self):
        central = BackgroundWidget()
        # ── background image ──────────────────────────────────────────
        # Place your PNG next to the script (or update the path below).
        # Safe to leave in even when the file does not exist yet.
        central.set_background(str(resource_path("aureo1.png")))
        self.setCentralWidget(central)
        lay = QVBoxLayout(central)
        lay.setAlignment(Qt.AlignCenter)

        splash = QFrame()
        splash.setFixedSize(380, 160)
        splash.setStyleSheet(
            f"background:{WHITE}; border-radius:18px; "
            f"border:1px solid {BORDER};"
        )
        s_lay = QVBoxLayout(splash)
        lbl = QLabel("✨ Loading TU_MyCo-Vision...\nPlease wait...")
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(
            f"color:{GREEN_MED}; font-size:11pt; font-weight:bold; border:none;"
        )
        s_lay.addWidget(lbl)
        self._splash_progress = QProgressBar()
        self._splash_progress.setRange(0, 100)
        self._splash_progress.setValue(10)
        self._splash_progress.setStyleSheet(
            f"QProgressBar::chunk {{ background:{GREEN_MED}; }}"
        )
        s_lay.addWidget(self._splash_progress)
        lay.addWidget(splash)

        # start heavy imports in a thread
        self._import_thread = _ImportThread()
        self._import_thread.done.connect(self._on_imports_done)
        self._import_thread.start()

        self._splash_timer = QTimer(self)
        self._splash_timer.timeout.connect(self._bump_splash)
        self._splash_timer.start(200)

    def _bump_splash(self):
        v = self._splash_progress.value()
        if v < 90:
            self._splash_progress.setValue(v + 8)

    def _on_imports_done(self):
        self._splash_timer.stop()
        self._splash_progress.setValue(100)
        QTimer.singleShot(400, self._build_main_ui)

    # ──────────────────────────────────────────────────────────────
    # Main UI
    # ──────────────────────────────────────────────────────────────
    def _build_main_ui(self):
        central = BackgroundWidget()
        central.set_background(str(resource_path("background.png")))
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(7, 6, 7, 6)

        # shared task progress bar (top of window)
        self.task_progress = QProgressBar()
        self.task_progress.setRange(0, 100)
        self.task_progress.setValue(0)
        self.task_progress.setFixedHeight(18)
        self.task_progress.setFormat("%p%")
        layout.addWidget(self.task_progress)

        self.tabs = QTabWidget()
        bold = QFont(QApplication.font())
        bold.setBold(True)
        self.tabs.tabBar().setFont(bold)
        # live output window below the tabs (drag the splitter to resize)
        self.log_panel = LogPanel()
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(self.tabs)
        splitter.addWidget(self.log_panel)
        splitter.setStretchFactor(0, 4)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([680, 170])
        layout.addWidget(splitter)

        detection_page = QWidget()
        analysis_page  = QWidget()
        results_page   = QWidget()
        self.tabs.addTab(detection_page, "Detection")
        self.tabs.addTab(analysis_page,  "Analysis")
        self.tabs.addTab(results_page,   "Results Dashboard")

        self._build_detection_tab(detection_page)
        self._build_analysis_tab(analysis_page)
        self._build_results_tab(results_page)

        log("TU_MyCo-Vision ready. Output of detection and analysis appears here.")
        if not resource_path("TU_MyCo-Vision.pt").exists():
            log(f"WARNING: model file not found: {resource_path('TU_MyCo-Vision.pt')}")

    def _set_progress(self, fraction: float):
        """Update the progress bar (connected to thread signals, runs in the GUI thread)."""
        self.task_progress.setValue(int(max(0.0, min(1.0, fraction)) * 100))

    def closeEvent(self, event):
        """Do not quit while a background thread is still running."""
        thread = self._active_thread
        if thread is not None:
            if hasattr(thread, "cancel"):
                thread.cancel()
            thread.wait(15000)
        super().closeEvent(event)

    def _set_status(self, text: str):
        self.task_progress.setFormat(f"%p%  {text}" if text else "%p%")

    # ══════════════════════════════════════════════════════════════
    # Detection Tab
    # ══════════════════════════════════════════════════════════════
    @staticmethod
    def _scrollable_layout(parent) -> QVBoxLayout:
        """Layout inside a scroll area: on a small window or big font the page
        scrolls instead of squeezing (and overlapping) its widgets."""
        outer = QVBoxLayout(parent)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        container = QWidget()
        scroll.setWidget(container)
        outer.addWidget(scroll)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        return layout, outer

    def _build_detection_tab(self, parent):
        layout, outer = self._scrollable_layout(parent)

        # ── 1. File I/O Block ──────────────────────────────────────
        io_group = QGroupBox("Select Image Folder(s) && Output Folder")
        io_group.setStyleSheet(
            f"QGroupBox {{ color:{GREEN_DARK}; font-size:12pt; }}"
        )
        io_lay = QGridLayout(io_group)
        io_lay.setSpacing(8)

        self._input_list = FolderListWidget(
            "input", "Select image folder",
            summarizer=self._summarize_images,
            recursive_text="Include subfolders (find images recursively)")
        btn_out = self._btn("Output Folder", BLUE_DARK)
        btn_out.clicked.connect(self.browse_output)
        self._output_path_lbl = self._path_label("")
        saved_out = settings().value("output_folder", "")
        if saved_out and Path(saved_out).is_dir():
            self.output_folder = saved_out
            self._output_path_lbl.setText(saved_out)
        io_lay.addWidget(self._input_list,       0, 0, 1, 2)
        io_lay.addWidget(btn_out,                1, 0)
        io_lay.addWidget(self._output_path_lbl,  1, 1)
        io_lay.setColumnStretch(0, 1)
        io_lay.setColumnStretch(1, 3)
        layout.addWidget(io_group)

        # ── 2. Middle row: Classes + Model Settings ────────────────
        mid_row = QHBoxLayout()
        mid_row.setSpacing(10)

        # ── 2a. Select Classes block ───────────────────────────────
        class_group = QGroupBox("Select Classes")
        class_group.setStyleSheet(
            f"QGroupBox {{ color:{GREEN_DARK}; font-size:12pt; }}"
        )
        class_lay = QGridLayout(class_group)
        class_lay.setSpacing(6)

        btn_guide = self._btn("ℹ️ Open Class Guide", YELLOW,
                              text_color=GREEN_DARK, font_size=10)
        btn_guide.clicked.connect(self.show_class_reference_popup)
        class_lay.addWidget(btn_guide, 0, 0, 1, 4)

        btn_all   = self._btn("Select All",      GREEN_LIGHT, text_color=GREEN_DARK)
        btn_clear = self._btn("Clear Selection", YELLOW,      text_color=GREEN_DARK)
        btn_custom = self._btn("Custom class names…", BLUE_DARK)
        btn_all.clicked.connect(self.select_all_classes)
        btn_clear.clicked.connect(self.clear_classes)
        btn_custom.clicked.connect(self.show_custom_class_names_popup)
        class_lay.addWidget(btn_all,    1, 0, 1, 2)
        class_lay.addWidget(btn_clear,  1, 2, 1, 2)
        class_lay.addWidget(btn_custom, 2, 0, 1, 4)

        self._class_checkboxes = []
        for i, cname in enumerate(self.CLASS_DISPLAY_ORDER):
            cb = QCheckBox(cname)
            cb.setChecked(self.selected_classes[i])
            cb.stateChanged.connect(
                lambda state, idx=i: self._on_class_checked(idx, state))
            row_i = 3 + i // 4
            col_i = i % 4
            class_lay.addWidget(cb, row_i, col_i)
            self._class_checkboxes.append(cb)

        # Custom names indicator label
        self._custom_names_indicator = QLabel("")
        self._custom_names_indicator.setStyleSheet(
            f"color:{BLUE_DARK}; font-size:8pt; font-style:italic;")
        class_lay.addWidget(self._custom_names_indicator, 7, 0, 1, 4)

        mid_row.addWidget(class_group, stretch=1)

        # ── 2b. Model Settings ─────────────────────────────────────
        model_group = QGroupBox("Model Settings")
        model_group.setStyleSheet(
            f"QGroupBox {{ color:{BLUE_DARK}; font-size:12pt; }}"
        )
        model_lay = QGridLayout(model_group)
        model_lay.setSpacing(6)

        model_lay.addWidget(QLabel("Confidence:"), 0, 0, Qt.AlignRight)
        self._conf_slider = QSlider(Qt.Horizontal)
        self._conf_slider.setRange(10, 100)
        self._conf_slider.setValue(int(self.confidence * 100))
        self._conf_slider.setTickInterval(5)
        self._conf_slider.valueChanged.connect(self._on_conf_changed)
        model_lay.addWidget(self._conf_slider, 0, 1)
        self._conf_lbl = QLabel(f"{self.confidence:.2f}")
        self._conf_lbl.setStyleSheet("font-weight:bold;")
        model_lay.addWidget(self._conf_lbl, 1, 1, Qt.AlignLeft)

        model_lay.addWidget(QLabel("Line Width:"), 2, 0, Qt.AlignRight)
        self._line_width_entry = QLineEdit(str(self.line_width))
        self._line_width_entry.setMinimumWidth(70)
        self._line_width_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        model_lay.addWidget(self._line_width_entry, 2, 1, Qt.AlignLeft)

        model_lay.addWidget(QLabel("Analysis Name:"), 3, 0, Qt.AlignRight)
        self._analysis_name_entry = QLineEdit(self.analysis_name)
        self._analysis_name_entry.setMinimumWidth(180)
        self._analysis_name_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        model_lay.addWidget(self._analysis_name_entry, 3, 1, Qt.AlignLeft)

        self._agnostic_cb = QCheckBox("Agnostic NMS")
        self._agnostic_cb.setChecked(self.agnostic_nms)
        model_lay.addWidget(self._agnostic_cb, 4, 0, Qt.AlignLeft)

        self._show_output_cb = QCheckBox("Show Output")
        self._show_output_cb.setChecked(self.show_output)
        model_lay.addWidget(self._show_output_cb, 4, 1, Qt.AlignLeft)

        mid_row.addWidget(model_group, stretch=1)
        layout.addLayout(mid_row)

        # ── 3. Predict Button ──────────────────────────────────────
        btn_pred = self._btn(
            "▶  Run MyCo-Vision Prediction",
            GREEN_MED, font_size=18, height=60
        )
        btn_pred.clicked.connect(self.run_prediction_threaded)
        self._btn_stop = self._btn("■ Stop", "#b5483a", font_size=14, height=60)
        self._btn_stop.setEnabled(False)
        self._btn_stop.clicked.connect(self._stop_task)
        pred_row = QHBoxLayout()
        pred_row.setContentsMargins(20, 6, 20, 14)
        pred_row.addWidget(btn_pred, 4)
        pred_row.addWidget(self._btn_stop, 1)
        outer.addLayout(pred_row)          # pinned below the scrolling page

    # ── Detection helpers ──────────────────────────────────────────
    def _on_class_checked(self, idx, state):
        self.selected_classes[idx] = (state == Qt.Checked)

    def _on_conf_changed(self, value):
        self.confidence = value / 100.0
        self._conf_lbl.setText(f"{self.confidence:.2f}")

    @staticmethod
    def _summarize_images(folders, recursive):
        leaves = discover_image_folders(folders, recursive)
        n = sum(len(l.images) for l in leaves)
        if not n:
            return ("No images found." if recursive else
                    "No images found. Tick 'Include subfolders' to search deeper.")
        return f"{n} images in {len(leaves)} folder(s)"

    def browse_output(self):
        path = ask_directory(self, "Select Output Folder", "output",
                             self.output_folder)
        if path:
            self.output_folder = path
            self._output_path_lbl.setText(path)
            settings().setValue("output_folder", path)

    def select_all_classes(self):
        for cb in self._class_checkboxes:
            cb.setChecked(True)

    def clear_classes(self):
        for cb in self._class_checkboxes:
            cb.setChecked(False)

    def show_class_reference_popup(self):
        img_path = resource_path("reference.png")
        dlg = ClassReferenceDialog(self, str(img_path))
        dlg.exec_()

    def show_custom_class_names_popup(self):
        # Pass current custom names to dialog converted to YOLO order for display
        yolo_current = canonical_to_yolo_names(self.custom_class_names)
        dlg = CustomClassNamesDialog(
            self,
            current_names=yolo_current,
            enabled=self.custom_names_enabled
        )
        if dlg.exec_() == QDialog.Accepted:
            enabled, yolo_names = dlg.get_values()
            self.custom_names_enabled = enabled
            # Store internally as canonical order (for CSV/plot pipelines)
            self.custom_class_names = yolo_to_canonical_names(yolo_names)
            if self.custom_names_enabled:
                self._custom_names_indicator.setText(
                    "✔ Custom class names active — Save Images forced OFF"
                )
            else:
                self._custom_names_indicator.setText("")

    # ── Task plumbing (one background task at a time) ──────────────
    def _start_task(self, thread) -> bool:
        if self._active_thread is not None:
            QMessageBox.information(
                self, "Busy",
                "Another task is still running. Please wait for it, or press Stop.")
            return False
        self._active_thread = thread
        thread.progress.connect(self._set_progress)
        thread.status.connect(self._set_status)
        self._set_progress(0.0)
        self._btn_stop.setEnabled(hasattr(thread, "cancel"))
        thread.start()
        return True

    def _end_task(self):
        thread, self._active_thread = self._active_thread, None
        if thread is not None:
            thread.wait()          # let the QThread finish before it is released
        self._btn_stop.setEnabled(False)
        self._set_progress(0.0)
        self._set_status("")

    def _stop_task(self):
        thread = self._active_thread
        if thread is not None and hasattr(thread, "cancel"):
            thread.cancel()
            log("Stop requested - finishing the current image ...")

    def run_prediction_threaded(self):
        # Collect current UI values
        input_folders       = self._input_list.folders()
        self.analysis_name  = self._analysis_name_entry.text().strip() or "Myco_Analysis"
        try:
            self.line_width = int(self._line_width_entry.text() or "2")
        except ValueError:
            QMessageBox.critical(self, "Input Error", "Line width must be a whole number.")
            return
        self.agnostic_nms   = self._agnostic_cb.isChecked()
        self.show_output    = self._show_output_cb.isChecked()

        selected_cls = [i for i, v in enumerate(self.selected_classes) if v]
        if not input_folders:
            QMessageBox.critical(self, "Input Error", "Please add at least one image folder.")
            return
        if not self.output_folder:
            QMessageBox.critical(self, "Input Error", "Please select an output folder.")
            return
        if not selected_cls:
            QMessageBox.critical(self, "Input Error", "Please select at least one class.")
            return

        # If custom names enabled → force save=False (we'll overlay ourselves)
        save_images = not self.custom_names_enabled

        thread = PredictionThread(
            input_folders   = input_folders,
            recursive       = self._input_list.recursive(),
            output_folder   = self.output_folder,
            confidence      = self.confidence,
            line_width      = self.line_width,
            selected_cls    = selected_cls,
            agnostic_nms    = self.agnostic_nms,
            show_output     = self.show_output,
            analysis_name   = self.analysis_name,
            save_images     = save_images,
            custom_names_enabled = self.custom_names_enabled,
            custom_class_names   = self.custom_class_names,
        )
        thread.finished.connect(self._on_pred_done)
        thread.error.connect(self._on_pred_error)
        self._start_task(thread)

    def _on_pred_done(self, msg):
        self._end_task()
        QMessageBox.information(self, "Done", msg)

    def _on_pred_error(self, msg):
        self._end_task()
        QMessageBox.critical(self, "Prediction Error", msg)

    # ══════════════════════════════════════════════════════════════
    # Analysis Tab
    # ══════════════════════════════════════════════════════════════
    def _build_analysis_tab(self, parent):
        layout, _outer = self._scrollable_layout(parent)

        # ── Class Exclusion block ──────────────────────────────────
        excl_group = QGroupBox(
            "Class Exclusion (Exclude && Merge Selected Classes as 'Others')"
        )
        excl_group.setStyleSheet(
            f"QGroupBox {{ color:{GREEN_DARK}; font-size:11pt; }}"
        )
        excl_lay = QGridLayout(excl_group)
        excl_lay.setSpacing(6)

        btn_clear_excl = self._btn("Clear Selection", YELLOW, text_color=GREEN_DARK)
        btn_clear_excl.clicked.connect(self.clear_excluded_classes)
        # 13 classes in two compact rows; the Clear button fills the last cell
        btn_clear_excl.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        excl_lay.addWidget(btn_clear_excl, 1, 6)
        for c in range(7):
            excl_lay.setColumnStretch(c, 1)

        self._excl_checkboxes = []
        for i, cname in enumerate(self.CLASS_NAMES_ORDERED):
            cb = QCheckBox(cname)
            cb.setChecked(self.excluded_classes[i])
            cb.stateChanged.connect(
                lambda state, idx=i: self._on_excl_checked(idx, state))
            excl_lay.addWidget(cb, i // 7, i % 7)
            self._excl_checkboxes.append(cb)
        layout.addWidget(excl_group)

        # ── Three ways to define groups ────────────────────────────
        self._analysis_tabs = QTabWidget()
        bold = QFont(QApplication.font())
        bold.setBold(True)
        self._analysis_tabs.tabBar().setFont(bold)
        self._analysis_tabs.addTab(self._build_single_group_page(), "Single Group")
        self._analysis_tabs.addTab(self._build_multi_group_page(),
                                   "Multi Group (one group per folder)")
        self._analysis_tabs.addTab(self._build_custom_group_page(),
                                   "Custom Groups (by text)")
        self._analysis_tabs.setMinimumHeight(430)
        layout.addWidget(self._analysis_tabs, 1)

    # ── Analysis page helpers ──────────────────────────────────────
    def _add_output_row(self, grid, row, key):
        btn = self._btn("Select Output Folder", BLUE_DARK)
        lbl = self._path_label("No folder selected")
        btn.clicked.connect(lambda: self._pick_analysis_output(key))
        grid.addWidget(btn, row, 0)
        grid.addWidget(lbl, row, 1)
        self._analysis_out_lbls[key] = lbl

    def _pick_analysis_output(self, key):
        path = ask_directory(self, "Select Output Folder for Analysis",
                             "analysis_out", self._analysis_out.get(key, ""))
        if path:
            self._analysis_out[key] = path
            self._analysis_out_lbls[key].setText(path)

    @staticmethod
    def _summarize_labels(folders, recursive):
        files = discover_label_files(folders, recursive)
        if not files:
            return ("No label (.txt) files found. Pick the folder that holds the "
                    "'labels' folder of a detection run.")
        return f"{len(files)} label file(s) found"

    def _build_single_group_page(self):
        page = QWidget()
        g = QGridLayout(page)
        g.setSpacing(6)

        btn_folder = self._btn("Select Results Folder", GREEN_MED)
        btn_folder.clicked.connect(self.browse_single_group_folder)
        self._sg_folder_lbl = self._path_label("No folder selected")
        g.addWidget(btn_folder, 0, 0)
        g.addWidget(self._sg_folder_lbl, 0, 1)

        self._sg_recursive_cb = QCheckBox(
            "Include subfolders (find label files recursively)")
        self._sg_recursive_cb.setChecked(True)
        self._sg_recursive_cb.toggled.connect(self._refresh_sg_summary)
        g.addWidget(self._sg_recursive_cb, 1, 0, 1, 2)
        self._sg_summary = QLabel("")
        self._sg_summary.setStyleSheet(f"color:{BLUE_DARK}; font-size:9pt; font-style:italic;")
        g.addWidget(self._sg_summary, 2, 0, 1, 2)

        self._add_output_row(g, 3, "sg")
        g.addWidget(QLabel("Analysis Name:"), 4, 0, Qt.AlignRight)
        self._sg_name_entry = QLineEdit(self.single_analysis_name)
        self._sg_name_entry.setMinimumWidth(220)
        g.addWidget(self._sg_name_entry, 4, 1, Qt.AlignLeft)

        btn_run = self._btn("Run Single Group Analysis", GREEN_DARK,
                            font_size=13, height=40)
        btn_run.clicked.connect(self.run_single_group_analysis_threaded)
        g.addWidget(btn_run, 5, 0, 1, 2)
        g.setColumnStretch(1, 1)
        g.setRowStretch(6, 1)
        return page

    def _build_multi_group_page(self):
        page = QWidget()
        g = QGridLayout(page)
        g.setSpacing(6)

        info = QLabel("Every folder you add becomes one group (named after the folder).")
        info.setStyleSheet(f"color:{BLUE_DARK}; font-size:9pt;")
        g.addWidget(info, 0, 0, 1, 2)
        self._mg_folders = FolderListWidget(
            "analysis_groups", "Add group folder",
            summarizer=self._summarize_labels,
            recursive_text="Include subfolders (find label files recursively)")
        g.addWidget(self._mg_folders, 1, 0, 1, 2)

        self._add_output_row(g, 2, "mg")
        g.addWidget(QLabel("Analysis Name:"), 3, 0, Qt.AlignRight)
        self._mg_name_entry = QLineEdit(self.multi_analysis_name)
        self._mg_name_entry.setMinimumWidth(220)
        g.addWidget(self._mg_name_entry, 3, 1, Qt.AlignLeft)

        btn_run = self._btn("Run Multi Group Analysis", BLUE_DARK,
                            font_size=13, height=40)
        btn_run.clicked.connect(self.run_multi_group_analysis_threaded)
        g.addWidget(btn_run, 4, 0, 1, 2)
        g.setColumnStretch(1, 1)
        g.setRowStretch(5, 1)
        return page

    def _build_custom_group_page(self):
        page = QWidget()
        g = QGridLayout(page)
        g.setSpacing(6)

        self._cg_folders = FolderListWidget(
            "analysis_custom", "Add results folder",
            summarizer=self._summarize_labels,
            recursive_text="Include subfolders (find label files recursively)")
        g.addWidget(self._cg_folders, 0, 0, 1, 2)
        self._cg_table = GroupTable()
        g.addWidget(self._cg_table, 1, 0, 1, 2)

        self._add_output_row(g, 2, "cg")
        g.addWidget(QLabel("Analysis Name:"), 3, 0, Qt.AlignRight)
        self._cg_name_entry = QLineEdit(self.custom_analysis_name)
        self._cg_name_entry.setMinimumWidth(220)
        g.addWidget(self._cg_name_entry, 3, 1, Qt.AlignLeft)

        btn_run = self._btn("Preview Groups…  (analysis starts after you approve)",
                            "#B8860B", font_size=13, height=40)
        btn_run.clicked.connect(self.run_custom_group_analysis_threaded)
        g.addWidget(btn_run, 4, 0, 1, 2)
        g.setColumnStretch(1, 1)
        g.setRowStretch(5, 1)
        return page

    # ── Analysis helpers ───────────────────────────────────────────
    def _on_excl_checked(self, idx, state):
        self.excluded_classes[idx] = (state == Qt.Checked)

    def clear_excluded_classes(self):
        for cb in self._excl_checkboxes:
            cb.setChecked(False)

    def browse_single_group_folder(self):
        path = ask_directory(self, "Select Results Folder for Single Group Analysis",
                             "analysis_single", self.single_group_folder)
        if path:
            self.single_group_folder = path
            self._sg_folder_lbl.setText(path)
            self._refresh_sg_summary()

    def _refresh_sg_summary(self, *_):
        if not self.single_group_folder:
            self._sg_summary.setText("")
            return
        self._sg_summary.setText(self._summarize_labels(
            [self.single_group_folder], self._sg_recursive_cb.isChecked()))

    def _launch_analysis(self, samples, name, save_dir, kind):
        excluded = [i for i, v in enumerate(self.excluded_classes) if v]
        custom_names = self.custom_class_names if self.custom_names_enabled else None
        thread = AnalysisThread(
            samples=samples, analysis_name=name, save_dir=save_dir,
            excluded_indices=excluded, custom_names=custom_names, kind=kind)
        thread.finished.connect(self._on_analysis_done)
        thread.error.connect(self._on_analysis_error)
        thread.csv_ready.connect(self._on_csv_ready)
        self._start_task(thread)

    def run_single_group_analysis_threaded(self):
        self.single_analysis_name = self._sg_name_entry.text().strip() or "SingleAnalysis"
        folder = self.single_group_folder
        if not folder or not Path(folder).exists():
            QMessageBox.critical(self, "Error", "Please select a valid folder.")
            return
        files = discover_label_files([folder], self._sg_recursive_cb.isChecked())
        if not files:
            QMessageBox.critical(self, "Error", "No label .txt files found in selected folder.")
            return
        save_dir = self._analysis_out["sg"] or self.output_folder or folder
        self._launch_analysis([(lf, None) for lf in files],
                              self.single_analysis_name, save_dir,
                              "Single-group analysis")

    def run_multi_group_analysis_threaded(self):
        self.multi_analysis_name = self._mg_name_entry.text().strip() or "MultiAnalysis"
        folders = self._mg_folders.folders()
        if not folders:
            QMessageBox.critical(self, "Error", "Please add at least one group folder.")
            return
        files = discover_label_files(folders, self._mg_folders.recursive())
        if not files:
            QMessageBox.critical(self, "Error", "No label .txt files found in any group folder.")
            return
        save_dir = self._analysis_out["mg"] or self.output_folder or folders[0]
        self._launch_analysis([(lf, lf.root_label) for lf in files],
                              self.multi_analysis_name, save_dir,
                              "Multi-group analysis")

    def run_custom_group_analysis_threaded(self):
        self.custom_analysis_name = self._cg_name_entry.text().strip() or "CustomGroupAnalysis"
        folders = self._cg_folders.folders()
        if not folders:
            QMessageBox.critical(self, "Error", "Please add at least one results folder.")
            return
        defs = self._cg_table.group_defs()
        if not defs:
            QMessageBox.critical(self, "Error", "Please type at least one group.")
            return
        problems = validate_patterns(defs)
        if problems:
            QMessageBox.critical(self, "Error", "\n".join(problems))
            return
        files = discover_label_files(folders, self._cg_folders.recursive())
        if not files:
            QMessageBox.critical(self, "Error", "No label .txt files found in the selected folders.")
            return

        policy = self._cg_table.conflict_policy()
        texts = [lf.match_text for lf in files]
        assignment = assign_groups(texts, defs, policy)
        dlg = GroupPreviewDialog(self, texts, assignment, policy)
        if dlg.exec_() != QDialog.Accepted:
            log("Custom-group analysis not approved - nothing was run.")
            return

        samples = []
        for gname, idxs in assignment.groups.items():
            samples += [(files[i], gname) for i in idxs]
        save_dir = self._analysis_out["cg"] or self.output_folder or folders[0]
        self._launch_analysis(samples, self.custom_analysis_name, save_dir,
                              "Custom-group analysis")

    def _on_analysis_done(self, msg):
        self._end_task()
        QMessageBox.information(self, "Done", msg)

    def _on_analysis_error(self, msg):
        self._end_task()
        QMessageBox.critical(self, "Analysis Error", msg)

    def _on_csv_ready(self, csv_path):
        self.last_analysis_csv = csv_path
        self._csv_lbl.setText(Path(csv_path).name)

    # ══════════════════════════════════════════════════════════════
    # Results Dashboard Tab
    # ══════════════════════════════════════════════════════════════
    def _build_results_tab(self, parent):
        layout = QVBoxLayout(parent)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # ── Button row ─────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_load  = self._btn("Load Analysis CSV", GREEN_DARK)
        btn_table = self._btn("View CSV Table",    BLUE_DARK)
        btn_plots = self._btn("Click to View Plots", "#B8860B")
        btn_dl = self._btn("⬇ Download all plots", GREEN_DARK)
        btn_load.clicked.connect(self.dashboard_load_csv)
        btn_table.clicked.connect(self.dashboard_view_csv_table)
        btn_plots.clicked.connect(self.dashboard_view_plots)
        btn_dl.clicked.connect(self.dashboard_download_all_plots)
        self._csv_lbl = QLabel("")
        self._csv_lbl.setStyleSheet(f"color:{TEXT_GREEN}; font-style:italic;")
        self._csv_lbl.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self._csv_lbl.setMinimumWidth(60)
        btn_row.addWidget(btn_load)
        btn_row.addWidget(btn_table)
        btn_row.addWidget(btn_plots)
        btn_row.addWidget(btn_dl)
        btn_row.addWidget(self._csv_lbl, 1)
        layout.addLayout(btn_row)

        # Image folder selectors (second row)
        folder_row = QHBoxLayout()
        btn_orig = self._btn("Original Images…", GREEN_MED)
        btn_pred = self._btn("Predicted Images…", BLUE_LIGHT)
        btn_orig.clicked.connect(lambda: self._set_dashboard_folder("orig"))
        btn_pred.clicked.connect(lambda: self._set_dashboard_folder("pred"))
        self._orig_folder_lbl = QLabel("")
        self._pred_folder_lbl = QLabel("")
        for lbl in (self._orig_folder_lbl, self._pred_folder_lbl):
            lbl.setMinimumWidth(120)
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            lbl.setStyleSheet(f"background:{PATH_BG}; color:{TEXT_GREEN}; padding:2px 4px; border:1px solid {BORDER}; border-radius:3px;")
        folder_row.addWidget(btn_orig)
        folder_row.addWidget(self._orig_folder_lbl, 1)
        folder_row.addWidget(btn_pred)
        folder_row.addWidget(self._pred_folder_lbl, 1)
        layout.addLayout(folder_row)

        # ── Inner tabs: Results | Image Viewer ─────────────────────
        inner_tabs = QTabWidget()
        layout.addWidget(inner_tabs)

        results_page = QWidget()
        viewer_page  = QWidget()
        inner_tabs.addTab(results_page, "Results")
        inner_tabs.addTab(viewer_page,  "Image Viewer")

        # Results page placeholder
        results_lay = QVBoxLayout(results_page)
        lbl = QLabel(
            "Click 'Click to View Plots' to view interactive results."
        )
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setStyleSheet(
            f"color:{BLUE_DARK}; font-size:13pt; font-weight:bold;"
        )
        results_lay.addWidget(lbl)

        # Image viewer page
        self._build_image_viewer(viewer_page)

    def _set_dashboard_folder(self, which):
        path = ask_directory(
            self, f"Select {'Original' if which == 'orig' else 'Predicted'} Images Folder",
            f"dashboard_{which}",
            self.orig_img_folder if which == "orig" else self.pred_img_folder)
        if path:
            if which == "orig":
                self.orig_img_folder = path
                self._orig_folder_lbl.setText(Path(path).name)
            else:
                self.pred_img_folder = path
                self._pred_folder_lbl.setText(Path(path).name)
            self._refresh_image_viewer()

    def dashboard_load_csv(self):
        start = (str(Path(self.last_analysis_csv).parent)
                 if self.last_analysis_csv else last_dir("csv"))
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Analysis CSV", start, "CSV Files (*.csv)"
        )
        if path and Path(path).exists():
            self.last_analysis_csv = path
            self._csv_lbl.setText(Path(path).name)
            remember_dir("csv", str(Path(path).parent))

    def dashboard_view_csv_table(self):
        if not self.last_analysis_csv or not Path(self.last_analysis_csv).exists():
            QMessageBox.information(self, "No Data", "No analysis CSV loaded.")
            return
        try:
            import pandas as _pd
            df = _pd.read_csv(self.last_analysis_csv)
        except Exception as e:
            QMessageBox.critical(self, "CSV Error", f"Could not read CSV: {e}")
            return
        dlg = CSVTableDialog(self, df)
        dlg.exec_()

    def dashboard_view_plots(self):
        if not self.last_analysis_csv or not Path(self.last_analysis_csv).exists():
            QMessageBox.information(self, "No Data", "No analysis CSV loaded.")
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)     # building plots takes a moment
        try:
            self._dashboard_generate_and_open_plots(self.last_analysis_csv)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Plot Error", f"Error creating plots:\n{e}")
            return
        QApplication.restoreOverrideCursor()

    # ── Image Viewer ───────────────────────────────────────────────
    def _build_image_viewer(self, parent):
        layout = QVBoxLayout(parent)
        layout.setSpacing(4)

        # Labels row
        label_row = QHBoxLayout()
        self._left_img_lbl  = QLabel("Original", alignment=Qt.AlignCenter)
        self._right_img_lbl = QLabel("Predicted", alignment=Qt.AlignCenter)
        for lbl in (self._left_img_lbl, self._right_img_lbl):
            lbl.setStyleSheet(f"color:{BLUE_DARK}; font-weight:bold;")
        label_row.addWidget(self._left_img_lbl)
        label_row.addWidget(self._right_img_lbl)
        layout.addLayout(label_row)

        # Image canvases
        canvas_row = QHBoxLayout()
        self._left_canvas  = ZoomPanLabel()
        self._right_canvas = ZoomPanLabel()
        canvas_row.addWidget(self._left_canvas)
        canvas_row.addWidget(self._right_canvas)
        layout.addLayout(canvas_row, stretch=1)

        # Navigation row
        nav_row = QHBoxLayout()
        self._btn_prev    = self._btn("⟨ Prev", BLUE_DARK, width=80)
        self._btn_next    = self._btn("Next ⟩", BLUE_DARK, width=80)
        self._img_counter = QLabel("")
        self._img_counter.setStyleSheet("font-size:10pt;")
        self._btn_prev.clicked.connect(self._viewer_prev)
        self._btn_next.clicked.connect(self._viewer_next)
        nav_row.addWidget(self._btn_prev)
        nav_row.addWidget(self._btn_next)
        nav_row.addWidget(self._img_counter)
        nav_row.addStretch()
        layout.addLayout(nav_row)

        # Thumbnail scroll bar
        thumb_scroll_area = QScrollArea()
        thumb_scroll_area.setFixedHeight(95)
        thumb_scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        thumb_scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        thumb_scroll_area.setWidgetResizable(True)
        self._thumb_widget = QWidget()
        self._thumb_layout = QHBoxLayout(self._thumb_widget)
        self._thumb_layout.setSpacing(2)
        self._thumb_layout.setContentsMargins(2, 2, 2, 2)
        self._thumb_layout.setAlignment(Qt.AlignLeft)
        thumb_scroll_area.setWidget(self._thumb_widget)
        thumb_scroll_area.setStyleSheet(f"background:{PATH_BG};")
        layout.addWidget(thumb_scroll_area)

        # Keyboard shortcuts
        for canvas in (self._left_canvas, self._right_canvas):
            canvas.setFocusPolicy(Qt.StrongFocus)
        self._left_canvas.keyPressEvent = self._viewer_key_press

        # Show placeholder
        self._show_viewer_placeholder()

    def _show_viewer_placeholder(self):
        self._left_canvas.setText(
            "Select both Original and Predicted image folders above!"
        )
        self._right_canvas.setText("No images")
        self._img_counter.setText("")

    def _refresh_image_viewer(self):
        import glob as _glob
        orig_dir = self.orig_img_folder
        pred_dir = self.pred_img_folder

        if not orig_dir or not Path(orig_dir).exists() \
                or not pred_dir or not Path(pred_dir).exists():
            self._show_viewer_placeholder()
            return

        orig_files = [p for p in Path(orig_dir).iterdir() if is_image(p)]
        pred_files = [p for p in Path(pred_dir).iterdir() if is_image(p)]
        orig_map   = {p.stem: p for p in orig_files}
        pred_map   = {p.stem: p for p in pred_files}
        matches    = sorted(set(orig_map.keys()) & set(pred_map.keys()))

        if not matches:
            self._left_canvas.setText("No matching basenames found between folders.")
            self._right_canvas.setText("No matches.")
            self._img_counter.setText("")
            return

        self._dashboard_matches  = matches
        self._dashboard_orig_map = {k: str(orig_map[k]) for k in matches}
        self._dashboard_pred_map = {k: str(pred_map[k]) for k in matches}
        self._dashboard_idx      = 0
        self._rebuild_thumbnails()
        self._viewer_show(0)

    def _rebuild_thumbnails(self):
        # Clear existing thumbnails
        while self._thumb_layout.count():
            item = self._thumb_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        from PIL import Image as _PILImage
        for i, base in enumerate(self._dashboard_matches):
            try:
                thumb = _PILImage.open(self._dashboard_orig_map[base]).resize((50, 50))
                data  = thumb.convert("RGBA").tobytes("raw", "RGBA")
                qimg  = QImage(data, 50, 50, QImage.Format_RGBA8888)
                pm    = QPixmap.fromImage(qimg)
            except Exception:
                pm = QPixmap(50, 50)
                pm.fill(QColor(BORDER))

            frame = QFrame()
            frame.setFixedSize(76, 80)
            frame.setStyleSheet(
                f"border:2px solid {'#21a179' if i == 0 else BORDER}; "
                f"border-radius:5px; "
                f"background:{'#e2ffe3' if i == 0 else '#f6f6f6'};"
            )
            f_lay = QVBoxLayout(frame)
            f_lay.setSpacing(1)
            f_lay.setContentsMargins(2, 2, 2, 2)

            img_lbl = QLabel()
            img_lbl.setPixmap(pm)
            img_lbl.setAlignment(Qt.AlignCenter)
            f_lay.addWidget(img_lbl)

            fname = base
            if len(fname) > 12:
                fname = fname[:11] + "…"
            txt_lbl = QLabel(fname)
            txt_lbl.setAlignment(Qt.AlignCenter)
            txt_lbl.setStyleSheet("font-size:7pt; border:none;")
            f_lay.addWidget(txt_lbl)

            # click handler
            frame.mousePressEvent = lambda e, idx=i: self._viewer_show(idx)
            img_lbl.mousePressEvent = lambda e, idx=i: self._viewer_show(idx)
            txt_lbl.mousePressEvent = lambda e, idx=i: self._viewer_show(idx)

            self._thumb_layout.addWidget(frame)

    def _viewer_show(self, idx):
        if not self._dashboard_matches:
            return
        self._dashboard_idx = idx
        base = self._dashboard_matches[idx]
        from PIL import Image as _PILImage
        try:
            img_o = _PILImage.open(self._dashboard_orig_map[base]).convert("RGB")
            img_p = _PILImage.open(self._dashboard_pred_map[base]).convert("RGB")
        except Exception as e:
            QMessageBox.warning(self, "Image Error", str(e))
            return
        self._left_canvas.set_pil_image(img_o)
        self._right_canvas.set_pil_image(img_p)
        self._left_img_lbl.setText(
            f"Original: {Path(self._dashboard_orig_map[base]).name}")
        self._right_img_lbl.setText(
            f"Predicted: {Path(self._dashboard_pred_map[base]).name}")
        self._img_counter.setText(
            f"Image {idx + 1} / {len(self._dashboard_matches)}")
        self._left_canvas.setFocus()

    def _viewer_prev(self):
        if self._dashboard_idx > 0:
            self._viewer_show(self._dashboard_idx - 1)

    def _viewer_next(self):
        if self._dashboard_idx < len(self._dashboard_matches) - 1:
            self._viewer_show(self._dashboard_idx + 1)

    def _viewer_key_press(self, event):
        if event.key() == Qt.Key_Left:
            self._viewer_prev()
        elif event.key() == Qt.Key_Right:
            self._viewer_next()
        else:
            QLabel.keyPressEvent(self._left_canvas, event)

    # ── Plots ──────────────────────────────────────────────────────
    def _dashboard_build_figures(self, csv_path):
        import pandas as _pd
        from myco_plots import analysis_name_from_csv, build_figures
        df = _pd.read_csv(csv_path)
        return build_figures(df), analysis_name_from_csv(csv_path)

    def _dashboard_generate_and_open_plots(self, csv_path):
        from myco_plots import combined_html, plot_file_name
        figs, name = self._dashboard_build_figures(csv_path)
        out_dir = Path(tempfile.mkdtemp(prefix="myco_plots_"))
        html_path = out_dir / plot_file_name(name, "all_plots")
        html_path.write_text(combined_html(figs, name), encoding="utf-8")
        webbrowser.open(html_path.as_uri())

    def dashboard_download_all_plots(self):
        if not self.last_analysis_csv or not Path(self.last_analysis_csv).exists():
            QMessageBox.information(self, "No Data", "No analysis CSV loaded.")
            return
        from myco_plots import export_figures, safe_name
        base = ask_directory(self, "Choose where to save all plots", "plots_out")
        if not base:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            figs, name = self._dashboard_build_figures(self.last_analysis_csv)
            out_dir = Path(base) / f"{safe_name(name)}_plots"
            paths = export_figures(figs, out_dir, name)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Plot Error", f"Error saving plots:\n{e}")
            return
        QApplication.restoreOverrideCursor()
        log(f"Saved {len(paths)} plot files to {out_dir}")
        QMessageBox.information(
            self, "Plots saved",
            f"{len(paths)} files saved in:\n{out_dir}\n\n"
            f"File names start with the analysis name, e.g.\n{paths[0].name}")

    # ──────────────────────────────────────────────────────────────
    # Utility widget factories
    # ──────────────────────────────────────────────────────────────
    @staticmethod
    def _btn(text, bg_color, text_color="white", font_size=12,
             height=None, width=None):
        btn = QPushButton(text)
        # Scale font_size relative to the application's base font point size
        app_pt = QApplication.font().pointSize()
        if app_pt <= 0:
            app_pt = 10
        # font_size arg is treated as a relative scale in px at 96 DPI base;
        # convert to pt and scale proportionally
        scaled_pt = max(7, round(app_pt * font_size / 10))
        style = (
            f"background-color:{bg_color}; color:{text_color}; "
            f"font-size:{scaled_pt}pt; font-weight:bold; "
            f"border-radius:6px; padding:0.4em 0.9em; border:none;"
        )
        btn.setStyleSheet(style)
        # Use expanding size policy so buttons grow/shrink with the window
        btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        # Size from the real text metrics so text is never clipped, whatever
        # the font, DPI or window size (fixed pixel heights squashed text).
        f = QFont(QApplication.font())
        f.setPointSize(scaled_pt)
        f.setBold(True)
        fm = QFontMetrics(f)
        pad_v = max(6, round(fm.height() * 0.45))
        min_h = fm.height() + 2 * pad_v
        if height:
            min_h = max(min_h, int(height * fm.height() / 18))   # 'height' is a size hint
            btn.setMaximumHeight(int(min_h * 1.6))
        btn.setMinimumHeight(min_h)
        btn.setMinimumWidth(fm.horizontalAdvance(text) + int(1.8 * fm.height())
                            if not width else width)
        if width:
            btn.setMaximumWidth(int(width * 2))
        return btn

    @staticmethod
    def _path_label(text=""):
        lbl = QLabel(text)
        lbl.setObjectName("path_label")
        lbl.setWordWrap(True)
        lbl.setMinimumHeight(24)
        lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        return lbl


# ═══════════════════════════════════════════════════════════════════
# Import Thread (splash loader)
# ═══════════════════════════════════════════════════════════════════
class _ImportThread(QThread):
    done = pyqtSignal()

    def run(self):
        global pd, np, cv2
        try:
            import pandas as _pd;  pd  = _pd
            import numpy  as _np;  np  = _np
            import cv2    as _cv2; cv2 = _cv2
            import scipy
            import plotly.graph_objs
        except ImportError:
            pass
        self.done.emit()


# ═══════════════════════════════════════════════════════════════════
# Prediction Worker Thread
# ═══════════════════════════════════════════════════════════════════
def make_run_dir(output_folder, name: str) -> Path:
    """`<output>/<name>`, or `<name>2`, `<name>3` ... if it already has content
    (same numbering as Ultralytics, so earlier runs are never overwritten)."""
    base = Path(output_folder)
    first = base / name
    if not first.exists() or not any(first.iterdir()):
        return first
    n = 2
    while (base / f"{name}{n}").exists():
        n += 1
    return base / f"{name}{n}"


def leaf_output_dir(run_dir: Path, leaf, single: bool) -> Path:
    """Where results of one image folder go.

    One folder only      -> directly in the run folder (same layout as v1).
    Several / recursive  -> <run>/<picked folder name>/<subfolder path>, so
                            images with the same file name never collide.
    """
    return run_dir if single else run_dir / leaf.root_label / leaf.rel


class PredictionThread(WorkerThread):
    def __init__(self, input_folders, recursive, output_folder, confidence,
                 line_width, selected_cls, agnostic_nms, show_output,
                 analysis_name, save_images, custom_names_enabled,
                 custom_class_names):
        super().__init__()
        self.input_folders       = input_folders
        self.recursive           = recursive
        self.output_folder       = output_folder
        self.confidence          = confidence
        self.line_width          = line_width
        self.selected_cls        = selected_cls
        self.agnostic_nms        = agnostic_nms
        self.show_output         = show_output
        self.analysis_name       = analysis_name
        self.save_images         = save_images
        self.custom_names_enabled = custom_names_enabled
        self.custom_class_names  = custom_class_names
        self._cancel             = False

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            with redirect_output():
                self._run()
        except Exception as e:
            import traceback
            log(traceback.format_exc())
            self.error.emit(str(e))

    @staticmethod
    def _imgsz_for(leaf, cv2_mod):
        """Model image size from the first readable image of the folder."""
        for f in leaf.images:
            img = cv2_mod.imread(str(f))
            if img is not None:
                h, w = img.shape[:2]
                return (max(32, round(h / 32) * 32), max(32, round(w / 32) * 32))
        return (640, 640)

    def _run(self):
        log("Scanning folders for images ...")
        leaves = discover_image_folders(self.input_folders, self.recursive)
        total = sum(len(l.images) for l in leaves)
        if not total:
            self.error.emit(
                "No images found in the selected folder(s)."
                + ("" if self.recursive else
                   "\nTick 'Include subfolders' to search deeper."))
            return
        log(f"Found {total} images in {len(leaves)} folder(s).")

        model_path = resource_path("TU_MyCo-Vision.pt")
        if not model_path.exists():
            self.error.emit(
                f"Model file not found:\n{model_path}\n\n"
                "Download TU_MyCo-Vision.pt from the GitHub release and place it "
                "next to the program (the installer does this for you).")
            return

        self.status.emit("Loading model ...")
        log("Loading model (first start can take a minute) ...")
        from ultralytics import YOLO
        import cv2 as _cv2
        hook_ultralytics_logging()
        model = YOLO(str(model_path))
        hook_ultralytics_logging()

        run_dir = make_run_dir(self.output_folder, self.analysis_name)
        single = len(leaves) == 1
        log(f"Results will be saved in: {run_dir}")

        done = overlays = 0
        for li, leaf in enumerate(leaves, 1):
            if self._cancel:
                break
            out_dir = leaf_output_dir(run_dir, leaf, single)
            log(f"[{li}/{len(leaves)}] {leaf.folder}  ({len(leaf.images)} images)")
            results = model.predict(
                source=[str(p) for p in leaf.images],
                imgsz=self._imgsz_for(leaf, _cv2),
                conf=self.confidence,
                line_width=self.line_width,
                classes=self.selected_cls,
                save=self.save_images,
                save_txt=True,
                save_conf=True,
                agnostic_nms=self.agnostic_nms,
                augment=True,
                show=self.show_output,
                name=out_dir.name,
                project=str(out_dir.parent),
                exist_ok=True,
                max_det=1000,
                stream=True,          # one result per image -> real progress
            )
            for _ in results:
                done += 1
                self.progress.emit(done / total)
                self.status.emit(f"Detecting {done}/{total}")
                if self._cancel:
                    break
            results.close()

            if self.custom_names_enabled and not self._cancel:
                label_dir = out_dir / "labels"
                if not label_dir.exists():
                    label_dir = out_dir
                # custom_class_names is in canonical (CLASSES_ALL) order;
                # draw_yolo_overlays indexes by YOLO class ID → convert first
                overlays += draw_yolo_overlays(
                    image_dir   = leaf.folder,
                    label_dir   = label_dir,
                    output_dir  = out_dir / "custom_overlays",
                    custom_names= canonical_to_yolo_names(self.custom_class_names),
                )

        if self._cancel:
            msg = (f"Stopped by user after {done} of {total} images.\n"
                   f"Results so far:\n{run_dir}")
        else:
            msg = (f"YOLO Prediction completed!\n"
                   f"{done} images in {len(leaves)} folder(s).\n"
                   f"Results:\n{run_dir}")
            if self.custom_names_enabled:
                msg += f"\n\nCustom overlays ({overlays} images) saved in 'custom_overlays' folders."
        log(msg.replace("\n\n", "\n"))
        self.progress.emit(1.0)
        self.finished.emit(msg)


# ═══════════════════════════════════════════════════════════════════
# Analysis Worker Thread (single group, multi group and custom groups)
# ═══════════════════════════════════════════════════════════════════
class AnalysisThread(WorkerThread):
    """Count cells in label files, write CSVs and export all plots.

    ``samples`` is a list of (LabelFile, group-name-or-None). If every group
    is None the table has no 'Group' column (single-group analysis).
    """
    csv_ready = pyqtSignal(str)

    def __init__(self, samples, analysis_name, save_dir, excluded_indices,
                 custom_names=None, kind="Analysis", auto_plots=True):
        super().__init__()
        self.samples          = samples
        self.analysis_name    = analysis_name
        self.save_dir         = save_dir
        self.excluded_indices = excluded_indices
        self.custom_names     = custom_names   # None or list of 13 strings
        self.kind             = kind
        self.auto_plots       = auto_plots

    def run(self):
        try:
            with redirect_output():
                self._run()
        except Exception as e:
            import traceback
            log(traceback.format_exc())
            self.error.emit(str(e))

    def _run(self):
        from myco_plots import build_figures, export_figures, safe_name
        n = len(self.samples)
        log(f"{self.kind}: reading {n} label file(s) ...")
        self.status.emit("Reading label files ...")
        self.progress.emit(0.02)

        df_raw = build_counts_frame(
            self.samples, progress=lambda f: self.progress.emit(0.02 + 0.5 * f))
        save_path = Path(self.save_dir)
        save_path.mkdir(parents=True, exist_ok=True)

        df_out = apply_custom_names(df_raw, self.custom_names)
        csv_path = save_path / f"{self.analysis_name}_rawdata.csv"
        df_out.to_csv(csv_path, index=False, encoding="utf-8")
        log(f"Saved {csv_path}")
        self.csv_ready.emit(str(csv_path))

        datasets = [(self.analysis_name, df_out)]
        if self.excluded_indices:
            names = self.custom_names or CLASSES_ALL
            df_mod = merge_excluded(df_out, [names[i] for i in self.excluded_indices])
            excl_path = save_path / f"{self.analysis_name}_excluded.csv"
            df_mod.to_csv(excl_path, index=False, encoding="utf-8")
            log(f"Saved {excl_path}")
            datasets.append((f"{self.analysis_name}_excluded", df_mod))

        plot_note = ""
        if self.auto_plots:
            plot_dir = save_path / f"{safe_name(self.analysis_name)}_plots"
            try:
                for k, (plot_name, df) in enumerate(datasets):
                    self.status.emit("Building plots ...")
                    self.progress.emit(0.6 + 0.35 * k / len(datasets))
                    log(f"Building plots for '{plot_name}' ...")
                    written = export_figures(build_figures(df), plot_dir, plot_name)
                log(f"Plots saved in {plot_dir}")
                plot_note = f"\nPlots (HTML) saved in:\n{plot_dir}"
            except Exception as e:                # analysis itself already succeeded
                import traceback
                log("Plot export failed:\n" + traceback.format_exc())
                plot_note = f"\n(Plot export failed: {e})"

        self.progress.emit(1.0)
        self.finished.emit(
            f"{self.kind} finished ({n} files).\n"
            f"CSVs saved in:\n{save_path}{plot_note}")


# ═══════════════════════════════════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    # pythonw.exe (Windows shortcut) has no console: sys.stdout/stderr are None.
    # Give libraries a harmless sink; the in-app Output log still gets everything.
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w")
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w")

    # High-DPI support
    if hasattr(Qt, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    # light palette + font families that exist on Windows, macOS and Linux
    apply_app_theme(app, make_app_font())

    window = MycoVisionApp()
    window.show()
    sys.exit(app.exec_())
