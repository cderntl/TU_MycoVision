"""TU_MyCo-Vision GUI helpers (PyQt5): remembered folders, multi-folder
picker, live log panel, group table and the group approval dialog."""

from __future__ import annotations

import io
import json
import logging
import re
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Callable, List, Optional

from PyQt5.QtCore import QObject, QSettings, Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont, QTextCursor
from PyQt5.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog,
    QDialogButtonBox, QFileDialog, QFileSystemModel, QHBoxLayout, QHeaderView,
    QLabel, QListView, QListWidget, QPlainTextEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QTreeView, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget,
)

from myco_core import GroupAssignment, GroupDef

_SMALL_BTN = ("QPushButton { background:#d2f8d2; color:#388659; font-weight:bold;"
              " border-radius:5px; padding:3px 9px; border:none; }"
              "QPushButton:disabled { background:#e6e6e6; color:#999; }")


def _small_button(text: str, tip: str = "") -> QPushButton:
    b = QPushButton(text)
    b.setStyleSheet(_SMALL_BTN)
    b.setMinimumHeight(b.fontMetrics().height() + 10)       # never squashed below the text
    b.setMinimumWidth(b.fontMetrics().horizontalAdvance(text) + 24)
    if tip:
        b.setToolTip(tip)
    return b


# ═══════════════════════════════════════════════════════════════════
# Remembered folders
# ═══════════════════════════════════════════════════════════════════
def settings() -> QSettings:
    return QSettings("TU_MyCo-Vision", "TU_MyCo-Vision")


def existing_start_dir(path: str) -> str:
    """Nearest existing folder at or above ``path`` (or the home folder)."""
    p = Path(path) if path else Path.home()
    for cand in [p, *p.parents]:
        try:
            if cand.is_dir():
                return str(cand)
        except OSError:
            continue
    return str(Path.home())


def last_dir(key: str) -> str:
    s = settings()
    return existing_start_dir(
        s.value(f"last_dir/{key}", s.value("last_dir/_any", "")) or "")


def remember_dir(key: str, path: str):
    s = settings()
    s.setValue(f"last_dir/{key}", path)
    s.setValue("last_dir/_any", path)


def ask_directory(parent, title: str, key: str, start: str = "") -> str:
    """Pick one folder. The dialog opens in the folder used last time."""
    path = QFileDialog.getExistingDirectory(
        parent, title, existing_start_dir(start) if start else last_dir(key))
    if path:
        remember_dir(key, path)
    return path


def ask_directories(parent, title: str, key: str) -> List[str]:
    """Pick one or more folders (Ctrl/Shift click) in a single dialog."""
    dlg = QFileDialog(parent, title, last_dir(key))
    dlg.setFileMode(QFileDialog.Directory)
    dlg.setOption(QFileDialog.ShowDirsOnly, True)
    dlg.setOption(QFileDialog.DontUseNativeDialog, True)   # native dialogs allow only one
    for view in dlg.findChildren(QListView) + dlg.findChildren(QTreeView):
        if isinstance(view.model(), QFileSystemModel):
            view.setSelectionMode(QAbstractItemView.ExtendedSelection)
    if not dlg.exec_():
        return []
    paths = [p for p in dlg.selectedFiles() if Path(p).is_dir()]
    if paths:
        remember_dir(key, str(Path(paths[-1]).parent))
    return paths


# ═══════════════════════════════════════════════════════════════════
# Live log (terminal output -> window)
# ═══════════════════════════════════════════════════════════════════
class LogBus(QObject):
    message = pyqtSignal(str)


BUS = LogBus()


class QtLogStream(io.TextIOBase):
    """File-like object: sends text to the log window and (if any) the terminal."""
    encoding = "utf-8"

    def __init__(self, tee=None):
        super().__init__()
        self._tee = tee

    def writable(self):
        return True

    def isatty(self):
        return False

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        if s:
            BUS.message.emit(s)
            if self._tee is not None:
                try:
                    self._tee.write(s)
                except Exception:
                    pass
        return len(s)

    def flush(self):
        if self._tee is not None:
            try:
                self._tee.flush()
            except Exception:
                pass


# sys.__stdout__ is None when started with pythonw (Windows shortcut)
_PERSISTENT = QtLogStream(sys.__stdout__)


def log(message: str = ""):
    """Write one line to the log window (and the terminal)."""
    _PERSISTENT.write(message + "\n")


@contextmanager
def redirect_output():
    """Send print() and stderr (e.g. progress bars) of the code inside to the log."""
    old_out, old_err = sys.stdout, sys.stderr
    sys.stdout = QtLogStream(old_out)
    sys.stderr = QtLogStream(old_err)
    try:
        yield
    finally:
        sys.stdout, sys.stderr = old_out, old_err


def hook_ultralytics_logging():
    """Make the 'ultralytics' logger write to the log window.

    Ultralytics creates its console handler once, bound to whatever stdout
    existed at import time; re-point it to our stream.
    """
    lg = logging.getLogger("ultralytics")
    for h in lg.handlers:
        if isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler):
            if not isinstance(getattr(h, "stream", None), QtLogStream):
                h.setStream(_PERSISTENT)


_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


class LogPanel(QWidget):
    """Read-only text window that shows everything sent through ``BUS``."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        head = QHBoxLayout()
        title = QLabel("Output log")
        title.setStyleSheet("font-weight:bold; color:#388659;")
        head.addWidget(title)
        head.addStretch()
        btn_copy = _small_button("Copy")
        btn_save = _small_button("Save log…")
        btn_clear = _small_button("Clear")
        btn_copy.clicked.connect(self._copy)
        btn_save.clicked.connect(self._save)
        btn_clear.clicked.connect(lambda: self.text.clear())
        for b in (btn_copy, btn_save, btn_clear):
            head.addWidget(b)
        lay.addLayout(head)

        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.setMaximumBlockCount(20000)
        self.text.setLineWrapMode(QPlainTextEdit.NoWrap)
        mono = QFont("Consolas" if sys.platform.startswith("win") else "Monospace")
        mono.setStyleHint(QFont.Monospace)
        mono.setPointSize(9)
        self.text.setFont(mono)
        self.text.setStyleSheet("background:#10201a; color:#d8f5e6;")
        self.text.setMinimumHeight(90)
        lay.addWidget(self.text)
        BUS.message.connect(self.append_text)

    def append_text(self, chunk: str):
        chunk = _ANSI.sub("", chunk)
        bar = self.text.verticalScrollBar()
        at_end = bar.value() >= bar.maximum() - 4
        cur = self.text.textCursor()
        cur.movePosition(QTextCursor.End)
        for part in re.split(r"(\r\n|\n|\r)", chunk):
            if part in ("\n", "\r\n"):
                cur.insertBlock()
            elif part == "\r":            # progress bars: rewrite the current line
                cur.movePosition(QTextCursor.StartOfBlock)
                cur.movePosition(QTextCursor.EndOfBlock, QTextCursor.KeepAnchor)
                cur.removeSelectedText()
            elif part:
                cur.insertText(part)
        if at_end:
            bar.setValue(bar.maximum())

    def _copy(self):
        QApplication.clipboard().setText(self.text.toPlainText())

    def _save(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save log", str(Path(last_dir("log")) / "myco_vision_log.txt"),
            "Text files (*.txt)")
        if path:
            Path(path).write_text(self.text.toPlainText(), encoding="utf-8")
            remember_dir("log", str(Path(path).parent))


# ═══════════════════════════════════════════════════════════════════
# Multi-folder list
# ═══════════════════════════════════════════════════════════════════
class _DropList(QListWidget):
    dropped = pyqtSignal(list)

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)

    def _dirs(self, event):
        return [u.toLocalFile() for u in event.mimeData().urls()
                if u.isLocalFile() and Path(u.toLocalFile()).is_dir()]

    def dragEnterEvent(self, event):
        (event.acceptProposedAction() if self._dirs(event) else event.ignore())

    def dragMoveEvent(self, event):
        (event.acceptProposedAction() if self._dirs(event) else event.ignore())

    def dropEvent(self, event):
        dirs = self._dirs(event)
        if dirs:
            self.dropped.emit(dirs)
            event.acceptProposedAction()


class FolderListWidget(QWidget):
    """A list of folders with add / add several / remove / clear.

    * remembers the folders and the 'recursive' choice between sessions
    * ``summarizer(folders, recursive) -> str`` fills a one-line summary
    """
    changed = pyqtSignal()

    def __init__(self, key: str, dialog_title: str,
                 summarizer: Optional[Callable] = None,
                 recursive_text: str = "Include subfolders (recursive)",
                 recursive_default: bool = True, persist: bool = True,
                 parent=None):
        super().__init__(parent)
        self._key = key
        self._title = dialog_title
        self._summarizer = summarizer
        self._persist = persist

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)

        self.list = _DropList()
        self.list.setTextElideMode(Qt.ElideMiddle)            # long paths: ...in the middle
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        row_h = self.list.fontMetrics().height() + 6
        self.list.setMinimumHeight(row_h * 3)
        self.list.setMaximumHeight(row_h * 4)
        self.list.setToolTip("Drag folders here, or use the buttons below.")
        self.list.dropped.connect(self.add_folders)
        lay.addWidget(self.list)

        row = QHBoxLayout()
        self._btn_add = _small_button("Add folder…")
        self._btn_multi = _small_button(
            "Add several…", "Pick several folders at once (Ctrl/Shift + click)")
        self._btn_rm = _small_button("Remove selected")
        self._btn_clear = _small_button("Clear")
        self._btn_add.clicked.connect(self._add_one)
        self._btn_multi.clicked.connect(self._add_many)
        self._btn_rm.clicked.connect(self._remove_selected)
        self._btn_clear.clicked.connect(self.clear)
        for b in (self._btn_add, self._btn_multi, self._btn_rm, self._btn_clear):
            row.addWidget(b)
        row.addStretch()
        lay.addLayout(row)

        self.recursive_cb = QCheckBox(recursive_text)
        self.recursive_cb.setChecked(recursive_default)
        self.recursive_cb.toggled.connect(self._on_changed)
        lay.addWidget(self.recursive_cb)

        self.summary = QLabel("")
        self.summary.setStyleSheet("color:#406882; font-size:9pt; font-style:italic;")
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)

        if persist:
            self._restore()
        self._refresh_summary()

    # ── public ────────────────────────────────────────────────────
    def folders(self) -> List[str]:
        return [self.list.item(i).text() for i in range(self.list.count())]

    def recursive(self) -> bool:
        return self.recursive_cb.isChecked()

    def add_folders(self, paths):
        existing = set(self.folders())
        added = False
        for p in paths:
            p = str(Path(p))
            if p and p not in existing and Path(p).is_dir():
                self.list.addItem(p)
                self.list.item(self.list.count() - 1).setToolTip(p)
                existing.add(p)
                added = True
        if added:
            self._on_changed()

    def clear(self):
        self.list.clear()
        self._on_changed()

    # ── internals ─────────────────────────────────────────────────
    def _add_one(self):
        p = ask_directory(self, self._title, self._key)
        if p:
            self.add_folders([p])

    def _add_many(self):
        self.add_folders(ask_directories(self, self._title + " (select several)", self._key))

    def _remove_selected(self):
        for item in self.list.selectedItems():
            self.list.takeItem(self.list.row(item))
        self._on_changed()

    def _on_changed(self, *_):
        if self._persist:
            s = settings()
            s.setValue(f"folders/{self._key}", json.dumps(self.folders()))
            s.setValue(f"recursive/{self._key}", self.recursive())
        self._refresh_summary()
        self.changed.emit()

    def _restore(self):
        s = settings()
        try:
            saved = json.loads(s.value(f"folders/{self._key}", "[]") or "[]")
        except (TypeError, ValueError):
            saved = []
        rec = s.value(f"recursive/{self._key}", None)
        if rec is not None:
            self.recursive_cb.blockSignals(True)
            self.recursive_cb.setChecked(str(rec).lower() in ("true", "1"))
            self.recursive_cb.blockSignals(False)
        for p in saved:
            if Path(p).is_dir():
                self.list.addItem(p)

    def _refresh_summary(self):
        if not self._summarizer or not self.folders():
            self.summary.setText("")
            return

        def work():
            try:
                self.summary.setText(self._summarizer(self.folders(), self.recursive()))
            except Exception as e:                      # never break the GUI for a label
                self.summary.setText(f"(could not scan: {e})")
        QTimer.singleShot(0, work)


# ═══════════════════════════════════════════════════════════════════
# Group definition table + approval dialog
# ═══════════════════════════════════════════════════════════════════
class GroupTable(QWidget):
    HELP = (
        "Type what identifies each group. Matching is case-insensitive and looks at the "
        "folder path and the file name. Separate several strings with commas. "
        "Use * and ? as wildcards, or start with re: for a regular expression. "
        "A string that matches two folders puts both folders into one group; "
        "a string that is part of file names groups those images. "
        "Group name is optional (the first string is used)."
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        info = QLabel(self.HELP)
        info.setWordWrap(True)
        info.setStyleSheet("color:#406882; font-size:9pt;")
        lay.addWidget(info)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Group name (optional)", "Match strings"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setMinimumHeight(150)
        self.table.setStyleSheet(
            "QTableWidget { background:#ffffff; color:#222222; }"
            "QHeaderView::section { background:#eafaf1; color:#222222; padding:3px; }"
            "QTableCornerButton::section { background:#eafaf1; }")
        lay.addWidget(self.table)

        row = QHBoxLayout()
        b_add = _small_button("+ Add group")
        b_rm = _small_button("− Remove selected")
        b_add.clicked.connect(lambda: self.add_row())
        b_rm.clicked.connect(self._remove_selected)
        row.addWidget(b_add)
        row.addWidget(b_rm)
        row.addStretch()
        row.addWidget(QLabel("If a file matches several groups:"))
        self.policy = QComboBox()
        self.policy.setStyleSheet("QComboBox { background:#ffffff; color:#222222; }"
                                  "QComboBox QAbstractItemView { background:#ffffff; color:#222222; }")
        self.policy.addItem("skip it (recommended)", "skip")
        self.policy.addItem("use the first matching group", "first")
        row.addWidget(self.policy)
        lay.addLayout(row)

        for _ in range(2):
            self.add_row()

    def add_row(self, name: str = "", patterns: str = ""):
        r = self.table.rowCount()
        self.table.insertRow(r)
        self.table.setItem(r, 0, QTableWidgetItem(name))
        self.table.setItem(r, 1, QTableWidgetItem(patterns))

    def _remove_selected(self):
        for r in sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True):
            self.table.removeRow(r)

    def group_defs(self) -> List[GroupDef]:
        defs = []
        for r in range(self.table.rowCount()):
            n = self.table.item(r, 0)
            p = self.table.item(r, 1)
            g = GroupDef.from_row(n.text() if n else "", p.text() if p else "")
            if g:
                defs.append(g)
        return defs

    def conflict_policy(self) -> str:
        return self.policy.currentData()


class GroupPreviewDialog(QDialog):
    """Shows which file goes to which group. Analysis starts only on Approve."""
    MAX_CHILDREN = 300

    def __init__(self, parent, texts: List[str], assignment: GroupAssignment,
                 policy: str):
        super().__init__(parent)
        self.setWindowTitle("Check the groups before analysis")
        self.resize(760, 560)
        lay = QVBoxLayout(self)

        n_assigned = len(assignment.assigned)
        non_empty = sum(1 for v in assignment.groups.values() if v)
        summary = QLabel(
            f"<b>{len(texts)}</b> files found. "
            f"<b>{n_assigned}</b> will be analysed in <b>{non_empty}</b> group(s). "
            f"<b>{len(assignment.unmatched)}</b> match no group. "
            f"<b>{len(assignment.conflicts)}</b> match more than one group "
            f"({'first group is used' if policy == 'first' else 'they are skipped'})."
        )
        summary.setWordWrap(True)
        lay.addWidget(summary)

        tree = QTreeWidget()
        tree.setHeaderLabels(["Group / file", "Files"])
        tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        lay.addWidget(tree)

        def add_section(title, idxs, extra=None, warn=False):
            top = QTreeWidgetItem([title, str(len(idxs))])
            if warn:
                top.setForeground(0, Qt.red)
            tree.addTopLevelItem(top)
            for i in idxs[:self.MAX_CHILDREN]:
                label = texts[i] + (f"   ← {', '.join(extra[i])}" if extra and i in extra else "")
                top.addChild(QTreeWidgetItem([label, ""]))
            if len(idxs) > self.MAX_CHILDREN:
                top.addChild(QTreeWidgetItem([f"… and {len(idxs) - self.MAX_CHILDREN} more", ""]))
            return top

        for name, idxs in assignment.groups.items():
            top = add_section(f"Group: {name}" + ("   (EMPTY - nothing matched)" if not idxs else ""),
                              idxs, warn=not idxs)
            top.setExpanded(bool(idxs) and len(assignment.groups) <= 6)
        if assignment.conflicts:
            add_section("Matches several groups", sorted(assignment.conflicts),
                        extra=assignment.conflicts, warn=True)
        if assignment.unmatched:
            add_section("Matches no group (not analysed)", assignment.unmatched, warn=True)

        buttons = QDialogButtonBox()
        self.ok_btn = buttons.addButton("Approve and run analysis",
                                        QDialogButtonBox.AcceptRole)
        buttons.addButton("Cancel - change the strings", QDialogButtonBox.RejectRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        self.ok_btn.setEnabled(n_assigned > 0)
        lay.addWidget(buttons)
