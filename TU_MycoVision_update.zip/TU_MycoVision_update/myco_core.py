"""TU_MyCo-Vision core helpers (no Qt, no ultralytics).

Everything here is plain Python so it can be unit-tested without a GUI:

* image discovery (flat or recursive)
* label (.txt) discovery and parsing
* count tables (pandas, imported lazily)
* group matching from user-typed strings
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# ═══════════════════════════════════════════════════════════════════
# Class tables
# ═══════════════════════════════════════════════════════════════════

# Canonical display order of the 13 classes (used for CSV columns / plots)
CLASSES_ALL = ["C1", "C2", "C2-B", "C3-B", "C5", "C8", "C9",
               "C4", "C6", "C11", "C7-E", "C7-F", "C7-G"]

# CORRECT_ALL[i] is the YOLO id of CLASSES_ALL[i]
CORRECT_ALL = [2, 0, 7, 8, 1, 9, 6, 3, 4, 5, 10, 11, 12]

# Class names listed by YOLO id (0-12), derived from CORRECT_ALL so the two
# tables can never disagree.
CLASSES_YOLO_ORDER = [CLASSES_ALL[CORRECT_ALL.index(i)] for i in range(13)]

# Cells cut by the image border are ignored, except for these YOLO ids
# (4=C6, 10=C7-E, 11=C7-F, 12=C7-G), which are always kept. Kept exactly as in v1.
BORDER_EXEMPT_IDS = (4, 10, 11, 12)
EPSILON = 0.001

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}

# Folders that hold our own output; never treated as input when scanning.
_SKIP_DIR_NAMES = {"custom_overlays", "labels", "__pycache__"}
# Text files that are not YOLO label files.
_NOT_LABEL_NAMES = {"classes.txt", "labels.txt", "readme.txt"}


def is_image(path: Path) -> bool:
    return Path(path).suffix.lower() in IMAGE_EXTENSIONS


def canonical_to_yolo_names(canonical_names: Sequence[str]) -> List[str]:
    """13 names in CLASSES_ALL order -> 13 names in YOLO id order."""
    yolo_names = [""] * 13
    for canonical_idx, yolo_id in enumerate(CORRECT_ALL):
        yolo_names[yolo_id] = canonical_names[canonical_idx]
    return yolo_names


def yolo_to_canonical_names(yolo_names: Sequence[str]) -> List[str]:
    """13 names in YOLO id order -> 13 names in CLASSES_ALL order."""
    return [yolo_names[yolo_id] for yolo_id in CORRECT_ALL]


# ═══════════════════════════════════════════════════════════════════
# Image discovery
# ═══════════════════════════════════════════════════════════════════
@dataclass
class LeafFolder:
    """One folder that directly contains images."""
    root: Path           # folder the user picked
    root_label: str      # unique, human-readable name of that root
    folder: Path         # folder holding the images
    images: List[Path] = field(default_factory=list)

    @property
    def rel(self) -> Path:
        """Folder path relative to the picked root ('.' for the root itself)."""
        return self.folder.relative_to(self.root)


def unique_root_labels(roots: Sequence[Path]) -> Dict[Path, str]:
    """Give each root a short unique label (folder name, extended if needed)."""
    roots = [Path(r) for r in roots]
    labels: Dict[Path, str] = {}
    for depth in range(1, 8):
        labels = {}
        for r in roots:
            parts = r.parts[-depth:] if r.parts else (str(r),)
            labels[r] = "_".join(p.strip("\\/:") or "root" for p in parts)
        if len(set(labels.values())) == len(roots):
            return labels
    # still ambiguous (should not happen): number them
    return {r: f"{labels[r]}_{i + 1}" for i, r in enumerate(roots)}


def _looks_like_prediction_output(folder: Path) -> bool:
    labels = folder / "labels"
    if not labels.is_dir():
        return False
    try:
        return any(p.suffix == ".txt" for p in labels.iterdir())
    except OSError:
        return False


def _sorted_dir_listing(folder: Path):
    try:
        names = sorted(os.listdir(folder), key=str.lower)
    except OSError:
        return [], []
    dirs, files = [], []
    for name in names:
        p = folder / name
        try:
            (dirs if p.is_dir() else files).append(p)
        except OSError:
            continue
    return dirs, files


def discover_image_folders(roots: Iterable, recursive: bool) -> List[LeafFolder]:
    """Find every folder that directly contains images.

    * ``recursive=False`` looks only at the picked folders themselves.
    * ``recursive=True`` also walks into subfolders. Hidden folders, our own
      ``custom_overlays`` folders and earlier prediction outputs (a folder
      with a ``labels`` subfolder) are skipped, so old results are not
      detected a second time.
    * A folder reachable twice (e.g. a parent and its child were both added)
      is only returned once.
    """
    root_paths: List[Path] = []
    for r in roots:
        p = Path(r)
        if p.is_dir() and p not in root_paths:
            root_paths.append(p)
    labels = unique_root_labels(root_paths)

    leaves: List[LeafFolder] = []
    seen: set = set()

    def visit(root: Path, folder: Path, is_root: bool):
        try:
            key = folder.resolve()
        except OSError:
            key = folder
        dirs, files = _sorted_dir_listing(folder)
        if key not in seen:
            images = [f for f in files if is_image(f)]
            if images and (is_root or not _looks_like_prediction_output(folder)):
                seen.add(key)
                leaves.append(LeafFolder(root, labels[root], folder, images))
        if recursive:
            for d in dirs:
                if d.name.startswith(".") or d.name in _SKIP_DIR_NAMES:
                    continue
                if d.is_symlink():
                    continue
                visit(root, d, False)

    for root in root_paths:
        visit(root, root, True)
    return leaves


def count_images(leaves: Iterable[LeafFolder]) -> int:
    return sum(len(l.images) for l in leaves)


# ═══════════════════════════════════════════════════════════════════
# Label discovery + parsing
# ═══════════════════════════════════════════════════════════════════
@dataclass
class LabelFile:
    path: Path
    root: Path
    root_label: str
    sample: str          # unique id: path below root, without 'labels/' and '.txt'

    @property
    def match_text(self) -> str:
        """Text that group strings are matched against."""
        return f"{self.root_label}/{self.sample}"


def _sample_id(root: Path, path: Path) -> str:
    rel = path.relative_to(root).with_suffix("")
    parts = [p for p in rel.parts[:-1] if p != "labels"] + [rel.parts[-1]]
    return "/".join(parts)


def _is_label_candidate(path: Path) -> bool:
    return path.suffix.lower() == ".txt" and path.name.lower() not in _NOT_LABEL_NAMES


def discover_label_files(roots: Iterable, recursive: bool = True) -> List[LabelFile]:
    """Find YOLO label files below the picked folders.

    If any ``labels`` folder exists below a root, only files inside such
    folders are used. Otherwise every .txt file counts (flat folder of labels).
    ``recursive=False`` keeps the original behaviour: ``<root>/labels/*.txt``
    or ``<root>/*.txt``.
    """
    root_paths: List[Path] = []
    for r in roots:
        p = Path(r)
        if p.is_dir() and p not in root_paths:
            root_paths.append(p)
    labels = unique_root_labels(root_paths)

    found: List[LabelFile] = []
    seen_files: set = set()
    for root in root_paths:
        if recursive:
            all_txt: List[Path] = []
            in_labels: List[Path] = []
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = sorted(
                    (d for d in dirnames if not d.startswith(".")), key=str.lower)
                for fn in sorted(filenames, key=str.lower):
                    p = Path(dirpath) / fn
                    if _is_label_candidate(p):
                        all_txt.append(p)
                        if Path(dirpath).name == "labels":
                            in_labels.append(p)
            chosen = in_labels or all_txt
        else:
            base = root / "labels" if (root / "labels").is_dir() else root
            chosen = sorted((p for p in base.glob("*.txt") if _is_label_candidate(p)),
                            key=lambda p: p.name.lower())
        for p in chosen:
            try:
                key = p.resolve()
            except OSError:
                key = p
            if key in seen_files:
                continue
            seen_files.add(key)
            found.append(LabelFile(p, root, labels[root], _sample_id(root, p)))
    return found


def parse_label_file(path: Path) -> List[int]:
    """Count cells per class in one YOLO label file.

    Returns 13 counts in canonical (CLASSES_ALL) order. Cells touching the
    image border are skipped (except BORDER_EXEMPT_IDS).
    """
    counts = [0] * 13
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            parts = line.strip().split()
            if len(parts) < 5:
                continue
            try:
                vals = [float(x) for x in parts]
            except ValueError:
                continue
            cid = int(vals[0])
            cx, cy, bw, bh = vals[1], vals[2], vals[3], vals[4]
            marginx = (abs((cx + bw / 2) - 1) < EPSILON or
                       (cx - bw / 2) < EPSILON)
            marginy = (abs((cy + bh / 2) - 1) < EPSILON or
                       (cy - bh / 2) < EPSILON)
            if (marginx or marginy) and cid not in BORDER_EXEMPT_IDS:
                continue
            if 0 <= cid < 13:
                counts[cid] += 1
    return [counts[j] for j in CORRECT_ALL]


def apply_custom_names(df, custom_names: Optional[Sequence[str]]):
    """Rename the 13 class columns using custom names (canonical order)."""
    if not custom_names:
        return df
    return df.rename(columns=dict(zip(CLASSES_ALL, custom_names)))


def build_counts_frame(samples: Sequence[Tuple[LabelFile, Optional[str]]],
                       progress=None):
    """Build the raw-count table.

    ``samples`` is a list of (LabelFile, group-or-None). If any group is not
    None the table gets a ``Group`` column (layout: classes, Group, Image),
    otherwise the layout is (Image, classes) as in earlier versions.
    """
    import pandas as pd
    rows, images, groups = [], [], []
    n = max(len(samples), 1)
    for i, (lf, group) in enumerate(samples):
        rows.append(parse_label_file(lf.path))
        images.append(lf.sample)
        groups.append(group)
        if progress:
            progress((i + 1) / n)
    df = pd.DataFrame(rows, columns=CLASSES_ALL)
    if any(g is not None for g in groups):
        df["Group"] = groups
        df["Image"] = images
    else:
        df.insert(0, "Image", images)
    return df


def merge_excluded(df, excluded_cols: Sequence[str]):
    """Sum the excluded class columns into one 'Others' column."""
    present = [c for c in excluded_cols if c in df.columns]
    out = df.copy()
    if present:
        out["Others"] = out[present].sum(axis=1)
        out.drop(columns=present, inplace=True)
    return out


# ═══════════════════════════════════════════════════════════════════
# Group matching from user strings
# ═══════════════════════════════════════════════════════════════════
@dataclass
class GroupDef:
    name: str
    patterns: List[str]

    @staticmethod
    def from_row(name: str, patterns_text: str) -> Optional["GroupDef"]:
        """Build a group from two text fields.

        * Patterns are separated by comma, semicolon or newline.
        * If only a name is typed, the name is also the pattern.
        * If only patterns are typed, the first pattern becomes the name.
        """
        name = (name or "").strip()
        patterns = [p.strip() for p in re.split(r"[,;\n]", patterns_text or "")
                    if p.strip()]
        if not patterns and name:
            patterns = [name]
        if not patterns:
            return None
        return GroupDef(name or patterns[0], patterns)


_regex_cache: Dict[str, "re.Pattern"] = {}


def compile_pattern(pattern: str) -> "re.Pattern":
    """Turn one user string into a case-insensitive regex (search semantics).

    * ``re:...``  -> raw regular expression
    * contains ``*`` or ``?`` -> wildcard (``*`` any text, ``?`` one character)
    * anything else -> plain "contains" text
    """
    cached = _regex_cache.get(pattern)
    if cached is not None:
        return cached
    if pattern.lower().startswith("re:"):
        rx = re.compile(pattern[3:], re.IGNORECASE)
    elif "*" in pattern or "?" in pattern:
        body = "".join(".*" if ch == "*" else "." if ch == "?" else re.escape(ch)
                       for ch in pattern)
        rx = re.compile(body, re.IGNORECASE)
    else:
        rx = re.compile(re.escape(pattern), re.IGNORECASE)
    _regex_cache[pattern] = rx
    return rx


def validate_patterns(defs: Sequence[GroupDef]) -> List[str]:
    """Return human-readable problems (bad regexes), empty list if fine."""
    problems = []
    for g in defs:
        for p in g.patterns:
            try:
                compile_pattern(p)
            except re.error as e:
                problems.append(f"Group '{g.name}': bad pattern '{p}' ({e})")
    return problems


def merge_group_defs(defs: Sequence[GroupDef]) -> List[GroupDef]:
    """Merge rows that use the same group name (case-insensitive)."""
    merged: Dict[str, GroupDef] = {}
    for g in defs:
        key = g.name.lower()
        if key in merged:
            for p in g.patterns:
                if p not in merged[key].patterns:
                    merged[key].patterns.append(p)
        else:
            merged[key] = GroupDef(g.name, list(g.patterns))
    return list(merged.values())


@dataclass
class GroupAssignment:
    groups: Dict[str, List[int]]            # group name -> indices into the input
    unmatched: List[int]
    conflicts: Dict[int, List[str]]         # index -> all groups that matched
    assigned: Dict[int, str]                # index -> final group (after policy)


def assign_groups(texts: Sequence[str], defs: Sequence[GroupDef],
                  conflict_policy: str = "skip") -> GroupAssignment:
    """Match each text against the groups.

    ``conflict_policy``: ``"skip"`` leaves items that match several groups
    out of the analysis; ``"first"`` puts them in the first matching group
    (order = order of the rows the user typed).
    """
    defs = merge_group_defs(defs)
    groups: Dict[str, List[int]] = {g.name: [] for g in defs}
    unmatched: List[int] = []
    conflicts: Dict[int, List[str]] = {}
    assigned: Dict[int, str] = {}
    for i, text in enumerate(texts):
        hits = [g.name for g in defs
                if any(compile_pattern(p).search(text) for p in g.patterns)]
        if not hits:
            unmatched.append(i)
            continue
        if len(hits) > 1:
            conflicts[i] = hits
            if conflict_policy != "first":
                continue
        assigned[i] = hits[0]
        groups[hits[0]].append(i)
    return GroupAssignment(groups, unmatched, conflicts, assigned)
