# ======================================================================
# TU_MyCo-Vision installer for Windows 10/11 (PowerShell 5.1 or newer)
#
#   Easiest: download install_windows.bat and double-click it.
#   Or in PowerShell:
#     iwr -useb https://raw.githubusercontent.com/cderntl/TU_MycoVision/main/installers/install_windows.ps1 | iex
#
# What it does (no admin rights needed):
#   1. gets the program files (or uses the clone it is started from)
#   2. finds conda - or installs Miniforge (a small conda) inside the install folder
#   3. creates a private conda environment from environment.yml
#   4. downloads the model + images from the GitHub release
#   5. creates Desktop and Start-menu shortcuts
#
# Options (arguments, or the same as environment variables):
#   -Dir PATH       install folder           (MYCO_HOME,    default %USERPROFILE%\TU_MyCo-Vision)
#   -Ref NAME       branch/tag to install    (MYCO_REF,     default main)
#   -Release TAG    release with model files (MYCO_RELEASE, default v1.0.0)
#   -DryRun         only print the steps
#   -NoShortcut     do not create shortcuts
# ======================================================================

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'      # makes Invoke-WebRequest much faster
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

function Env-Or($name, $default) {
    $v = [Environment]::GetEnvironmentVariable($name)
    if ([string]::IsNullOrWhiteSpace($v)) { return $default } else { return $v }
}

$Repo       = Env-Or 'MYCO_REPO'    'cderntl/TU_MycoVision'
$Ref        = Env-Or 'MYCO_REF'     'main'
$ReleaseTag = Env-Or 'MYCO_RELEASE' 'v1.0.0'
$InstallDir = Env-Or 'MYCO_HOME'    (Join-Path $env:USERPROFILE 'TU_MyCo-Vision')
$SourceUrl  = Env-Or 'MYCO_SOURCE_URL' ''        # override for forks/tests (a .zip)
$DryRun     = $false
$NoShortcut = $false
$MainScript = 'TU_MyCo-Vision_v1_source_code.py'
$Assets     = @('TU_MyCo-Vision.pt', 'aureo1.png', 'reference.png')

# simple argument parsing (works with "iwr | iex" too, where param() is not available)
for ($i = 0; $i -lt $args.Count; $i++) {
    switch -Regex ($args[$i]) {
        '^-Dir$'        { $InstallDir = $args[++$i] }
        '^-Ref$'        { $Ref        = $args[++$i] }
        '^-Release$'    { $ReleaseTag = $args[++$i] }
        '^-DryRun$'     { $DryRun     = $true }
        '^-NoShortcut$' { $NoShortcut = $true }
        default         { throw "Unknown option: $($args[$i])" }
    }
}
if ([string]::IsNullOrWhiteSpace($SourceUrl)) { $SourceUrl = "https://github.com/$Repo/archive/$Ref.zip" }

function Say($m)  { Write-Host ""; Write-Host "==> $m" -ForegroundColor Green }
function Note($m) { Write-Host "    $m" }
function Fail($m) { Write-Host ""; Write-Host "ERROR: $m" -ForegroundColor Red; throw $m }

function Download($url, $dest) {
    if ($DryRun) { Note "[dry-run] download $url -> $dest"; return }
    for ($try = 1; $try -le 3; $try++) {
        try { Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest; return }
        catch { if ($try -eq 3) { Fail "Download failed: $url`n$($_.Exception.Message)" }; Start-Sleep -Seconds (2 * $try) }
    }
}

function Run-Native($exe, $arguments) {
    if ($DryRun) { Note "[dry-run] $exe $($arguments -join ' ')"; return }
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { Fail "Command failed (exit code $LASTEXITCODE): $exe $($arguments -join ' ')" }
}

if ([Environment]::Is64BitOperatingSystem -eq $false) { Fail "A 64-bit Windows is required." }

try {
    Say "TU_MyCo-Vision installer (Windows)"
    Note "Install folder : $InstallDir"
    Note "Source         : $Repo @ $Ref"
    if ($DryRun) { Note "DRY RUN - nothing will be changed." }
    if ($InstallDir -match '\s') { Note "Warning: the install path contains a space; this can break some packages. Consider -Dir C:\TU_MyCo-Vision" }
    if (-not $DryRun) { New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null }

    # ── 1. program files ────────────────────────────────────────────
    $ScriptDir = $null
    if ($PSScriptRoot) { $ScriptDir = $PSScriptRoot }
    if ($ScriptDir -and (Test-Path (Join-Path (Split-Path $ScriptDir -Parent) $MainScript))) {
        $AppDir = Split-Path $ScriptDir -Parent
        Say "1/5 Using the program files in $AppDir"
    } else {
        $AppDir = Join-Path $InstallDir 'app'
        Say "1/5 Downloading the program files"
        if ($DryRun) { Note "[dry-run] download $SourceUrl -> $AppDir" }
        else {
            $tmp = Join-Path ([IO.Path]::GetTempPath()) ("myco_" + [guid]::NewGuid().ToString('N'))
            New-Item -ItemType Directory -Force -Path $tmp | Out-Null
            $zip = Join-Path $tmp 'src.zip'
            Download $SourceUrl $zip
            Expand-Archive -Path $zip -DestinationPath $tmp -Force
            $found = Get-ChildItem -Path $tmp -Recurse -Filter $MainScript | Select-Object -First 1
            if (-not $found) { Fail "The downloaded archive does not contain $MainScript." }
            New-Item -ItemType Directory -Force -Path $AppDir | Out-Null
            Copy-Item -Path (Join-Path $found.DirectoryName '*') -Destination $AppDir -Recurse -Force
            Remove-Item -Recurse -Force $tmp
        }
    }

    # ── 2. conda ────────────────────────────────────────────────────
    Say "2/5 Looking for conda"
    $conda = $null
    $cmd = Get-Command conda -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source -and (Test-Path $cmd.Source) -and ($cmd.Source -like '*.exe')) { $conda = $cmd.Source }
    if (-not $conda) {
        $candidates = @(
            (Join-Path $InstallDir 'miniforge3\Scripts\conda.exe'),
            (Join-Path $env:USERPROFILE 'miniforge3\Scripts\conda.exe'),
            (Join-Path $env:USERPROFILE 'mambaforge\Scripts\conda.exe'),
            (Join-Path $env:USERPROFILE 'miniconda3\Scripts\conda.exe'),
            (Join-Path $env:USERPROFILE 'anaconda3\Scripts\conda.exe'),
            (Join-Path $env:LOCALAPPDATA 'miniforge3\Scripts\conda.exe'),
            (Join-Path $env:LOCALAPPDATA 'miniconda3\Scripts\conda.exe'),
            'C:\ProgramData\miniforge3\Scripts\conda.exe',
            'C:\ProgramData\miniconda3\Scripts\conda.exe',
            'C:\ProgramData\anaconda3\Scripts\conda.exe')
        foreach ($c in $candidates) { if (Test-Path $c) { $conda = $c; break } }
    }
    if ($conda) { Note "Found conda: $conda" }
    else {
        $mfPrefix = Join-Path $InstallDir 'miniforge3'
        Note "conda not found - installing Miniforge into $mfPrefix"
        $mfUrl = 'https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Windows-x86_64.exe'
        $mfExe = Join-Path ([IO.Path]::GetTempPath()) 'Miniforge3-Windows-x86_64.exe'
        Download $mfUrl $mfExe
        if ($DryRun) { Note "[dry-run] run $mfExe /S /InstallationType=JustMe /AddToPath=0 /RegisterPython=0 /D=$mfPrefix" }
        else {
            # /D must be the last argument and must not be quoted
            $p = Start-Process -FilePath $mfExe -Wait -PassThru -ArgumentList @(
                '/S', '/InstallationType=JustMe', '/AddToPath=0', '/RegisterPython=0', "/D=$mfPrefix")
            if ($p.ExitCode -ne 0) { Fail "Miniforge installation failed (exit code $($p.ExitCode))." }
            Remove-Item -Force $mfExe -ErrorAction SilentlyContinue
        }
        $conda = Join-Path $mfPrefix 'Scripts\conda.exe'
        if (-not $DryRun -and -not (Test-Path $conda)) { Fail "conda.exe was not found after installing Miniforge." }
    }

    # ── 3. environment ──────────────────────────────────────────────
    $EnvDir = Join-Path $InstallDir 'env'
    Say "3/5 Creating the Python environment (a few GB download; this takes a while)"
    Note "Environment folder: $EnvDir"
    $envYml = Join-Path $AppDir 'environment.yml'
    if (Test-Path (Join-Path $EnvDir 'python.exe')) {
        Note "Environment exists - updating it."
        Run-Native $conda @('env', 'update', '-p', $EnvDir, '-f', $envYml, '--prune')
    } else {
        Run-Native $conda @('env', 'create', '-p', $EnvDir, '-f', $envYml, '-y')
    }

    # ── 4. model + images ───────────────────────────────────────────
    Say "4/5 Downloading the model and images (release $ReleaseTag)"
    foreach ($f in $Assets) {
        $target = Join-Path $AppDir $f
        if ((Test-Path $target) -and ((Get-Item $target).Length -gt 0)) { Note "$f already present - skipped"; continue }
        Note "downloading $f"
        Download "https://github.com/$Repo/releases/download/$ReleaseTag/$f" "$target.part"
        if (-not $DryRun) { Move-Item -Force "$target.part" $target }
    }
    if (-not $DryRun) {
        $size = (Get-Item (Join-Path $AppDir 'TU_MyCo-Vision.pt')).Length
        if ($size -lt 1000000) { Fail "TU_MyCo-Vision.pt looks incomplete ($size bytes). Delete it and run the installer again." }
    }

    # ── 5. launchers + shortcuts ────────────────────────────────────
    Say "5/5 Creating the launchers"
    $launch = Join-Path $InstallDir 'TU_MyCo-Vision.bat'
    $launchConsole = Join-Path $InstallDir 'TU_MyCo-Vision_with_console.bat'
    # Same effect as "conda activate": put the environment on PATH, then start Python.
    $header = @"
@echo off
set "ENVDIR=$EnvDir"
set "CONDA_PREFIX=%ENVDIR%"
set "PATH=%ENVDIR%;%ENVDIR%\Library\mingw-w64\bin;%ENVDIR%\Library\usr\bin;%ENVDIR%\Library\bin;%ENVDIR%\Scripts;%PATH%"
cd /d "$AppDir"
"@
    $bodyGui     = "start `"`" `"%ENVDIR%\pythonw.exe`" `"$AppDir\$MainScript`" %*`r`n"
    $bodyConsole = "`"%ENVDIR%\python.exe`" `"$AppDir\$MainScript`" %*`r`npause`r`n"
    if ($DryRun) { Note "[dry-run] write $launch and $launchConsole" }
    else {
        Set-Content -Path $launch        -Value ($header + "`r`n" + $bodyGui)     -Encoding ASCII
        Set-Content -Path $launchConsole -Value ($header + "`r`n" + $bodyConsole) -Encoding ASCII
    }

    if (-not $NoShortcut -and -not $DryRun) {
        $shell = New-Object -ComObject WScript.Shell
        $targets = @(
            (Join-Path ([Environment]::GetFolderPath('Desktop')) 'TU_MyCo-Vision.lnk'),
            (Join-Path ([Environment]::GetFolderPath('Programs')) 'TU_MyCo-Vision.lnk'))
        foreach ($lnk in $targets) {
            try {
                $s = $shell.CreateShortcut($lnk)
                $s.TargetPath       = $launch
                $s.WorkingDirectory = $AppDir
                $s.WindowStyle      = 7           # minimized: hides the short-lived console
                $s.Description      = 'TU_MyCo-Vision - fungal morphology detection'
                $s.Save()
                Note "Shortcut: $lnk"
            } catch { Note "Could not create shortcut $lnk ($($_.Exception.Message))" }
        }
    }

    # ── check ───────────────────────────────────────────────────────
    if (-not $DryRun) {
        Say "Checking the installation"
        $env:QT_QPA_PLATFORM = 'offscreen'
        $oldPath = $env:PATH
        $env:PATH = "$EnvDir;$EnvDir\Library\mingw-w64\bin;$EnvDir\Library\usr\bin;$EnvDir\Library\bin;$EnvDir\Scripts;$oldPath"
        & (Join-Path $EnvDir 'python.exe') -c "import PyQt5.QtWidgets, pandas, scipy, plotly, cv2, torch, ultralytics; print('all packages import fine')"
        $ok = ($LASTEXITCODE -eq 0)
        $env:PATH = $oldPath
        Remove-Item Env:\QT_QPA_PLATFORM -ErrorAction SilentlyContinue
        if (-not $ok) { Fail "The environment was created, but a package failed to import. See the message above." }
    }

    Say "Done."
    Note "Start the program from the Desktop / Start-menu shortcut 'TU_MyCo-Vision',"
    Note "or run: $launch"
    Note "If it does not start, run TU_MyCo-Vision_with_console.bat to see the error."
    Note "Update later: run this installer again."
    Note "Uninstall:    delete the folder $InstallDir and the two shortcuts."
}
catch {
    Write-Host ""
    Write-Host "Installation stopped: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
