@echo off
rem ====================================================================
rem  TU_MyCo-Vision installer for Windows - just double-click this file.
rem  It starts install_windows.ps1 (next to this file, or downloaded).
rem  Extra options are passed on, e.g.:  install_windows.bat -DryRun
rem ====================================================================
setlocal
set "PS1=%~dp0install_windows.ps1"
if not defined MYCO_REPO set "MYCO_REPO=cderntl/TU_MycoVision"
if not defined MYCO_REF  set "MYCO_REF=main"

if not exist "%PS1%" (
  echo install_windows.ps1 not found next to this file - downloading it ...
  set "PS1=%TEMP%\myco_install_windows.ps1"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri 'https://raw.githubusercontent.com/%MYCO_REPO%/%MYCO_REF%/installers/install_windows.ps1' -OutFile '%TEMP%\myco_install_windows.ps1'"
  if errorlevel 1 (
    echo Could not download the installer. Check your internet connection.
    pause
    exit /b 1
  )
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (echo Finished.) else (echo The installation did not finish. Please read the messages above.)
pause
exit /b %RC%
