#!/usr/bin/env bash
# ======================================================================
# TU_MyCo-Vision installer for Linux and macOS
#
#   Download this file, then run:      bash install_linux_macos.sh
#   or in one line:
#     curl -fsSL https://raw.githubusercontent.com/cderntl/TU_MycoVision/main/installers/install_linux_macos.sh | bash
#
# What it does (nothing needs admin rights):
#   1. gets the program files (or uses the clone it is started from)
#   2. finds conda - or installs Miniforge (a small conda) inside the install folder
#   3. creates a private conda environment from environment.yml
#   4. downloads the model + images from the GitHub release
#   5. adds a start menu / launcher entry
#
# Options (or the same as environment variables):
#   --dir PATH       install folder           (MYCO_HOME,    default ~/TU_MyCo-Vision)
#   --ref NAME       branch/tag to install    (MYCO_REF,     default main)
#   --release TAG    release with model files (MYCO_RELEASE, default v1.0.0)
#   --dry-run        only print the steps
#   --no-shortcut    do not create launcher entries
#   --help
# ======================================================================
set -euo pipefail

REPO="${MYCO_REPO:-cderntl/TU_MycoVision}"
REF="${MYCO_REF:-main}"
RELEASE_TAG="${MYCO_RELEASE:-v1.0.0}"
SOURCE_URL="${MYCO_SOURCE_URL:-https://github.com/$REPO/archive/$REF.tar.gz}"   # override for forks/tests
INSTALL_DIR="${MYCO_HOME:-$HOME/TU_MyCo-Vision}"
DRY_RUN=0
SHORTCUT=1
MAIN_SCRIPT="TU_MyCo-Vision_v1_source_code.py"
ASSETS=("TU_MyCo-Vision.pt" "aureo1.png" "reference.png")

say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
note() { printf '    %s\n' "$*"; }
die() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

usage() { sed -n '2,26p' "$0" 2>/dev/null | sed 's/^# \{0,1\}//'; exit 0; }

while [ $# -gt 0 ]; do
  case "$1" in
    --dir) INSTALL_DIR="$2"; shift 2 ;;
    --ref) REF="$2"; shift 2 ;;
    --release) RELEASE_TAG="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    --no-shortcut) SHORTCUT=0; shift ;;
    -h|--help) usage ;;
    *) die "Unknown option: $1 (try --help)" ;;
  esac
done

# Run a command, or only print it in --dry-run mode.
run() {
  if [ "$DRY_RUN" = 1 ]; then printf '    [dry-run] %s\n' "$*"; else "$@"; fi
}

# ── tools ───────────────────────────────────────────────────────────
if command -v curl >/dev/null 2>&1; then
  fetch() { curl -fL --retry 3 --retry-delay 2 -o "$2" "$1"; }
elif command -v wget >/dev/null 2>&1; then
  fetch() { wget -q --tries=3 -O "$2" "$1"; }
else
  die "Neither curl nor wget found. Please install one of them first."
fi
command -v tar >/dev/null 2>&1 || die "tar is required."

OS="$(uname -s)"
ARCH="$(uname -m)"
case "$OS" in
  Linux)  MF_OS="Linux" ;;
  Darwin) MF_OS="MacOSX" ;;
  *) die "Unsupported system '$OS'. Use install_windows.bat on Windows." ;;
esac
case "$ARCH" in
  x86_64|amd64) MF_ARCH="x86_64" ;;
  arm64|aarch64) MF_ARCH=$([ "$OS" = Darwin ] && echo arm64 || echo aarch64) ;;
  *) die "Unsupported CPU '$ARCH'." ;;
esac

say "TU_MyCo-Vision installer ($OS $ARCH)"
note "Install folder : $INSTALL_DIR"
note "Source         : $REPO @ $REF"
[ "$DRY_RUN" = 1 ] && note "DRY RUN - nothing will be changed."
case "$INSTALL_DIR" in *" "*) note "Warning: the install path contains a space; this can break some packages." ;; esac
run mkdir -p "$INSTALL_DIR"

# ── 1. program files ────────────────────────────────────────────────
SCRIPT_DIR=""
if [ -n "${BASH_SOURCE[0]:-}" ] && [ -f "${BASH_SOURCE[0]}" ]; then
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fi

if [ -n "$SCRIPT_DIR" ] && [ -f "$SCRIPT_DIR/../$MAIN_SCRIPT" ]; then
  APP_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
  say "1/5 Using the program files in $APP_DIR"
else
  APP_DIR="$INSTALL_DIR/app"
  say "1/5 Downloading the program files"
  if [ "$DRY_RUN" = 1 ]; then
    note "[dry-run] download $SOURCE_URL -> $APP_DIR"
  else
    TMP="$(mktemp -d)"
    trap 'rm -rf "$TMP"' EXIT
    fetch "$SOURCE_URL" "$TMP/src.tar.gz" \
      || die "Could not download the source for '$REF'. Check your internet connection and the branch name."
    mkdir -p "$APP_DIR"
    # keep already downloaded model/images, replace the code
    tar -xzf "$TMP/src.tar.gz" -C "$TMP"
    SRC="$(find "$TMP" -maxdepth 2 -name "$MAIN_SCRIPT" -print -quit | xargs -I{} dirname {})"
    [ -n "$SRC" ] || die "The downloaded archive does not contain $MAIN_SCRIPT."
    cp -R "$SRC"/. "$APP_DIR"/
  fi
fi

# ── 2. conda ────────────────────────────────────────────────────────
say "2/5 Looking for conda"
CONDA=""
for c in "$(command -v conda 2>/dev/null || true)" \
         "$INSTALL_DIR/miniforge3/bin/conda" \
         "$HOME/miniforge3/bin/conda" "$HOME/mambaforge/bin/conda" \
         "$HOME/miniconda3/bin/conda" "$HOME/anaconda3/bin/conda" \
         "/opt/conda/bin/conda" "/opt/miniforge3/bin/conda" "/opt/anaconda3/bin/conda"; do
  if [ -n "$c" ] && [ -x "$c" ]; then CONDA="$c"; break; fi
done

if [ -n "$CONDA" ]; then
  note "Found conda: $CONDA"
else
  note "conda not found - installing Miniforge into $INSTALL_DIR/miniforge3"
  MF_URL="https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-$MF_OS-$MF_ARCH.sh"
  if [ "$DRY_RUN" = 1 ]; then
    note "[dry-run] download $MF_URL and run it with -b -p $INSTALL_DIR/miniforge3"
    CONDA="$INSTALL_DIR/miniforge3/bin/conda"
  else
    MF_DIR="$(mktemp -d)"
    MF_TMP="$MF_DIR/miniforge_installer.sh"      # the installer insists on a .sh file name
    fetch "$MF_URL" "$MF_TMP" || die "Could not download Miniforge from $MF_URL"
    bash "$MF_TMP" -b -p "$INSTALL_DIR/miniforge3" || die "Miniforge installation failed."
    rm -rf "$MF_DIR"
    CONDA="$INSTALL_DIR/miniforge3/bin/conda"
  fi
fi

# ── 3. environment ──────────────────────────────────────────────────
ENV_DIR="$INSTALL_DIR/env"
say "3/5 Creating the Python environment (a few GB download; this takes a while)"
note "Environment folder: $ENV_DIR"
if [ -x "$ENV_DIR/bin/python" ]; then
  note "Environment exists - updating it."
  run "$CONDA" env update -p "$ENV_DIR" -f "$APP_DIR/environment.yml" --prune
else
  run "$CONDA" env create -p "$ENV_DIR" -f "$APP_DIR/environment.yml" -y
fi
PY="$ENV_DIR/bin/python"

# ── 4. model + images ───────────────────────────────────────────────
say "4/5 Downloading the model and images (release $RELEASE_TAG)"
for f in "${ASSETS[@]}"; do
  target="$APP_DIR/$f"
  if [ -s "$target" ]; then
    note "$f already present - skipped"
    continue
  fi
  note "downloading $f"
  if [ "$DRY_RUN" = 1 ]; then
    note "[dry-run] https://github.com/$REPO/releases/download/$RELEASE_TAG/$f"
  else
    fetch "https://github.com/$REPO/releases/download/$RELEASE_TAG/$f" "$target.part" \
      || die "Could not download $f from release $RELEASE_TAG."
    mv "$target.part" "$target"
  fi
done
if [ "$DRY_RUN" != 1 ]; then
  size=$(wc -c < "$APP_DIR/TU_MyCo-Vision.pt" | tr -d ' ')
  [ "$size" -gt 1000000 ] || die "TU_MyCo-Vision.pt looks incomplete ($size bytes). Delete it and run the installer again."
fi

# ── 5. launcher ─────────────────────────────────────────────────────
say "5/5 Creating the launcher"
LAUNCHER="$INSTALL_DIR/TU_MyCo-Vision.sh"
if [ "$DRY_RUN" = 1 ]; then
  note "[dry-run] write $LAUNCHER"
else
  cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
# Starts TU_MyCo-Vision (written by the installer)
cd "$APP_DIR" || exit 1
exec "$PY" "$APP_DIR/$MAIN_SCRIPT" "\$@"
EOF
  chmod +x "$LAUNCHER"
fi

if [ "$SHORTCUT" = 1 ] && [ "$DRY_RUN" != 1 ]; then
  if [ "$OS" = "Linux" ]; then
    mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
    ln -sf "$LAUNCHER" "$HOME/.local/bin/tu-myco-vision"
    DESKTOP_FILE="$HOME/.local/share/applications/tu-myco-vision.desktop"
    cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=TU_MyCo-Vision
Comment=Fungal cell morphology detection and analysis
Exec="$LAUNCHER"
Path=$APP_DIR
Icon=$APP_DIR/aureo1.png
Terminal=false
Categories=Science;Education;
EOF
    chmod +x "$DESKTOP_FILE"
    command -v update-desktop-database >/dev/null 2>&1 \
      && update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
    note "Menu entry : TU_MyCo-Vision (Applications / Science)"
    note "Terminal   : tu-myco-vision   (add ~/.local/bin to PATH if the command is not found)"
  else
    APP_BUNDLE="$HOME/Applications/TU_MyCo-Vision.app"
    mkdir -p "$APP_BUNDLE/Contents/MacOS"
    cat > "$APP_BUNDLE/Contents/Info.plist" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>TU_MyCo-Vision</string>
  <key>CFBundleDisplayName</key><string>TU_MyCo-Vision</string>
  <key>CFBundleIdentifier</key><string>at.tugraz.tu-myco-vision</string>
  <key>CFBundleExecutable</key><string>TU_MyCo-Vision</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
EOF
    cat > "$APP_BUNDLE/Contents/MacOS/TU_MyCo-Vision" <<EOF
#!/bin/bash
exec "$LAUNCHER"
EOF
    chmod +x "$APP_BUNDLE/Contents/MacOS/TU_MyCo-Vision"
    note "App       : $APP_BUNDLE  (open it from Finder > Applications, or drag it to the Dock)"
  fi
fi

# ── check ───────────────────────────────────────────────────────────
if [ "$DRY_RUN" != 1 ]; then
  say "Checking the installation"
  if QT_QPA_PLATFORM=offscreen "$PY" -c "import PyQt5.QtWidgets, pandas, scipy, plotly, cv2, torch, ultralytics; print('all packages import fine')"; then
    :
  else
    die "The environment was created, but a package failed to import. See the message above."
  fi
fi

say "Done."
note "Start the program with:  $LAUNCHER"
note "Update later:            run this installer again."
note "Uninstall:               delete $INSTALL_DIR"
[ "$OS" = Linux ] && note "                          and ~/.local/share/applications/tu-myco-vision.desktop, ~/.local/bin/tu-myco-vision"
[ "$OS" = Darwin ] && note "                          and ~/Applications/TU_MyCo-Vision.app"
exit 0
